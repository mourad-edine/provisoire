<?php

function floatToInt($float) {
    return (int) $float;
}

?>