<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">VENTE</h1>
    <p class="mb-4">Ajouter votre vente.</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center bg-light border-bottom shadow-sm">
            <div class="d-flex">
                <a href="<?php echo e(route('vente.liste')); ?>" class="btn btn-outline-primary btn-sm font-weight-bold mr-2 px-3 shadow-sm">Listes ventes</a>
                <a href="<?php echo e(route('commande.liste.vente')); ?>" class="btn btn-outline-success btn-sm font-weight-bold px-3 shadow-sm">Listes par commandes</a>
            </div>
            <div class="d-flex">

                <!-- <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#venteModal">Nouvelle vente</button> -->
                <button class="btn btn-primary btn-sm"><a class="text-white text-decoration-none" href="<?php echo e(route('vente.page')); ?>">Nouvelle vente</a></button>

            </div>
        </div>

        <div class="card-body">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Art.</th>
                            <th>commande</th>
                            <th>consi(CGT/BTL)</th>
                            <th>état BTL</th>
                            <th>état CGT</th>
                            <th>état</th>
                            <th>Quantité</th>
                            <!-- <th>(P.U)</th> -->
                            <th>(Prix)</th>
                            <th>total</th>
                            <th>Date vente</th>
                            <th>Options</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($vente['id']); ?></td>
                            <td><?php echo e($vente['article']); ?></td>
                            <td>C-<?php echo e($vente['numero_commande']); ?></td>
                            <td>
                                <?php if($vente['consignation'] && $vente['prix_cgt']): ?>
                                <?php echo e($vente['consignation'] + $vente['prix_cgt']); ?> Ar
                                <?php elseif($vente['consignation']): ?>
                                <?php echo e($vente['consignation']); ?> Ar
                                <?php elseif($vente['prix_cgt']): ?>
                                <?php echo e($vente['prix_cgt']); ?> Ar
                                <?php else: ?>
                                non consi°
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="<?php echo e($vente['etat'] == 'non rendu' ? 'text-danger' : ''); ?>">
                                    <?php echo e($vente['etat'] ?? 'non consi°'); ?>

                                </span>
                            </td>
                            <td>
                                <span class="<?php echo e($vente['etat_cgt'] == 'non rendu' ? 'text-danger' : ''); ?>">
                                    <?php echo e($vente['etat_cgt'] ?? 'non consi°'); ?>

                                </span>
                            </td>
                            <td>
                                <p class="text-success">payé</p>
                            </td>
                            <td><?php echo e($vente['quantite']); ?> <?php echo e($vente['type_achat']); ?></td>
                            <!-- <td><?php echo e($vente['prix_unitaire']); ?> Ar</td> -->
                            <td><?php echo e($vente['btl'] == 0 ? $vente['prix_unitaire'] + $vente['prix_consignation'] : $vente['prix_unitaire']); ?> Ar</td>
                            <!-- <td>
                                <?php
                                if($vente['type_achat'] == 'bouteille'){
                                    $prix_total = $vente['prix_unitaire'] * $vente['quantite'];
                                    if($vente['cgt'] == 0 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'] + $vente['prix_cgt'];
                                    }else if($vente['cgt'] == 1 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'];
                                    }else if($vente['cgt']== 0 && $vente['btl'] == 1){
                                        $prix_total += $vente['prix_cgt'];
                                    }else{
                                        $prix_total += 0;
                                    }
                                }else if ($vente['type_achat'] === 'cageot') {
                                    $prix_total = $vente['prix_unitaire'] * $vente['quantite'] * $vente['conditionnement'];
                                    if($vente['cgt'] == 0 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'] + $vente['prix_cgt'];
                                    }else if($vente['cgt'] == 1 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'];
                                    }else if($vente['cgt']== 0 && $vente['btl'] == 1){
                                        $prix_total += $vente['prix_cgt'];
                                    }else{
                                        $prix_total += 0;
                                    }
                                }
                                ?>

                                <?php echo e($prix_total); ?> Ar
                            </td> -->
                            <td>
                                <?php
                                $prix_total = $vente['prix_unitaire'] * $vente['quantite'];

                                if ($vente['type_achat'] === 'cageot') {
                                $prix_total *= $vente['conditionnement'];
                                }

                                // Gestion des frais supplémentaires en fonction de cgt et btl
                                $prix_total += match (true) {
                                $vente['cgt'] == 0 && $vente['btl'] == 0 => $vente['consignation'] + $vente['prix_cgt'],
                                $vente['cgt'] == 1 && $vente['btl'] == 0 => $vente['consignation'],
                                $vente['cgt'] == 0 && $vente['btl'] == 1 => $vente['prix_cgt'],
                                default => 0,
                                };
                                ?>

                                <?php echo e(number_format($prix_total, 0, ',', ' ')); ?> Ar
                            </td>

                            <td><?php echo e(\Carbon\Carbon::createFromTimestamp($vente['created_at'])->format('d-m-Y')); ?></td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-edit"></i></a>
                                <a target="_blank" href="<?php echo e(route('pdf.download', $vente['commande_id'])); ?>"><i class="fa fa-archive" aria-hidden="true"></i></i></a>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-warning">Pas encore de données insérées pour le moment</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-start mt-3">
                    <?php echo e($ventes->links('pagination::bootstrap-4')); ?> <!-- ou 'pagination::bootstrap-5' -->
                </div>
            </div>
        </div>
    </div>

</div>
<!-- Button trigger modal -->
<div class="modal fade" id="venteModal2" tabindex="-1" role="dialog" aria-labelledby="venteModal2Label" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="venteModal2Label">Nombre de cageot</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="embale">nombre de cageot</label>
                            <h3 class="text-success" id="tot">0</h3>
                            <input type="number" class="form-control" id="embale" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">Valider</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nouvelle vente -->
<div class="modal fade" id="venteModal" tabindex="-1" role="dialog" aria-labelledby="venteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="venteModalLabel">Nouvelle vente</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="venteForm" method="POST" action="<?php echo e(route('vente.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <!-- Première ligne : Clients et Numéro de commande -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="client">Clients</label>
                                <select class="form-control select-search" id="client" name="client_id">
                                    <option value="">--client passager--</option>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->nom); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="cm">Numéro commande</label>
                                <input type="text" value="C-<?php echo e($dernier->id + 1); ?>" class="form-control" id="cm" disabled>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Deuxième ligne : Article et Date -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="article">Article</label>
                                <select class="form-control select-search" id="article">
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($article->id); ?>" data-prix="<?php echo e($article->prix_unitaire); ?>" data-condi="<?php echo e($article->conditionnement); ?>" data-consignation="<?php echo e($article->prix_consignation); ?>"><?php echo e($article->nom); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="dateachat">Date</label>
                                <input type="date" class="form-control" id="datevente" value="today" disabled>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Troisième ligne : Achat par unité ou cageot -->
                        <div class="col-md-6">
                            <div class="unitecontainer">
                                <div class="col-md-12 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="achatUnite">
                                        <label class="form-check-label" for="achatUnite">Achat par unité</label>
                                    </div>
                                </div>
                                <div id="quantiteCageotContainer">
                                    <div class="form-group">
                                        <label for="quantiteCageot">Quantité en cageot</label>
                                        <input type="number" class="form-control" id="quantiteCageot" min="1" value="1">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="cageotcontainer">
                                <div class="col-md-12 mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="achatCageot" checked>
                                        <label class="form-check-label" for="achatCageot">Achat par cageot</label>
                                    </div>
                                </div>
                                <div id="quantiteUniteContainer" style="display: none;">
                                    <div class="form-group">
                                        <label for="quantiteUnite">Quantité en unité</label>
                                        <input type="number" class="form-control" id="quantiteUnite" min="1" value="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3 d-flex justify-content-start">
                            <div class="form-check mr-3">
                                <input class="form-check-input" type="checkbox" id="non">
                                <label class="form-check-label" for="non">non consingé</label>
                            </div>
                            <div class="form-check mr-3">
                                <input class="form-check-input" type="checkbox" id="avec" disabled>
                                <label class="form-check-label" for="avec">Avec bouteille</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="cgt" disabled>
                                <label class="form-check-label" for="cgt">avec cageot</label>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3 d-flex form-check ml-3">
                            <input class="form-check-input" type="checkbox" id="unite">
                            <label class="form-check-label" for="unite">conditionner unité</label>
                        </div>
                    </div>

                    <button type="button" class="btn btn-success" id="ajouterArticle">Ajouter</button>

                    <!-- Conteneur caché pour stocker les valeurs envoyées en POST -->
                    <div id="hiddenInputs"></div>

                    <table class="table mt-3">
                        <thead>
                            <tr>
                                <th>Article</th>
                                <th>P.U</th>
                                <th>Prix consigné</th>
                                <th>Quantité</th>
                                <th>Cgt</th>
                                <th>BTL</th>
                                <th>état</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="articlesTable"></tbody>
                    </table>

                    <div class="modal-footer">
                        <p id="final" class="ml-5">0</p><span>Ar</span><button type="submit" class="btn btn-primary">Valider</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const achatUnite = document.getElementById("achatUnite");
        const achatCageot = document.getElementById("achatCageot");
        const quantiteCageotContainer = document.getElementById("quantiteCageotContainer");
        const quantiteUniteContainer = document.getElementById("quantiteUniteContainer");
        const non = document.getElementById('non');
        const avec = document.getElementById('avec');
        const final = document.getElementById('final'); // Assurez-vous que cet élément existe
        const prix_cgt = 3000;
        const cgt_checkbox = document.getElementById('cgt');
        const unite = document.getElementById('unite');
        const tot = document.getElementById('tot');

        function toggleDisplay() {
            if (achatUnite.checked) {
                quantiteUniteContainer.style.display = "block";
                quantiteCageotContainer.style.display = "none";
                achatCageot.checked = false;
            } else {
                quantiteUniteContainer.style.display = "none";
                quantiteCageotContainer.style.display = "block";
                achatCageot.checked = true;
            }
        }

        if (non) {
            non.addEventListener("change", function() {
                if (!non.checked) {
                    avec.checked = false; // Désactive "Avec"
                    avec.disabled = true;
                    cgt_checkbox.checked = false; // Désactive "Cageot"
                    cgt_checkbox.disabled = true;
                } else {
                    avec.disabled = false;
                    cgt_checkbox.disabled = false;
                }
            });
        }

        if (avec) {
            avec.addEventListener("change", function() {
                if (!avec.checked && !non.checked) {
                    avec.checked = false;
                }
            });
        }

        if (achatUnite) achatUnite.addEventListener("change", toggleDisplay);
        if (achatCageot) {
            achatCageot.addEventListener("change", function() {
                achatUnite.checked = !achatCageot.checked;
                toggleDisplay();
            });
        }

        document.getElementById('datevente').value = new Date().toISOString().split('T')[0];
        let totalQuantiteUnite = 0;
        document.getElementById('ajouterArticle').addEventListener('click', function() {
            let articleSelect = document.getElementById('article');
            let datevente = document.getElementById('datevente').value;
            let selectedOption = articleSelect.options[articleSelect.selectedIndex];

            if (!selectedOption) {
                alert("Veuillez sélectionner un article.");
                return;
            }

            let articleId = selectedOption.value || "";
            let articleNom = selectedOption.text || "";
            let prix = parseInt(selectedOption.getAttribute('data-prix'), 10) || 0;
            let conditionnement = parseInt(selectedOption.getAttribute('data-condi'), 10) || 1;
            let prix_consignation = parseInt(selectedOption.getAttribute('data-consignation'), 10) || 0;

            let quantite = achatUnite.checked ?
                parseInt(document.getElementById('quantiteUnite').value, 10) || 0 :
                parseInt(document.getElementById('quantiteCageot').value, 10) || 0;
            let types = achatUnite.checked ? '1' : '0';
            let consignation = non.checked ? 'non consigné' : 'consigné';

            if (quantite <= 0) {
                alert("Veuillez saisir une quantité valide.");
                return;
            }
            totalQuantiteUnite += achatUnite.checked ? quantite : quantite * conditionnement;
            tot.innerHTML = totalQuantiteUnite;
            console.log(totalQuantiteUnite);
            let total = avec.checked ?
                (cgt_checkbox.checked ? ((prix * quantite) + prix_cgt) : prix * quantite) :
                (cgt_checkbox.checked ? ((prix + prix_consignation) * quantite) + prix_cgt : (prix + prix_consignation) * quantite);

            let totalconsignecageot = avec.checked ?
                (cgt_checkbox.checked ? prix * conditionnement * quantite : (prix * conditionnement * quantite) + (prix_cgt * quantite)) :
                (cgt_checkbox.checked ? (prix_consignation + prix) * conditionnement * quantite : ((prix_consignation + prix) * conditionnement * quantite) + (prix_cgt * quantite));

            let totalcageot = non.checked ?
                prix * quantite * conditionnement :
                totalconsignecageot;

            let totalActuel = parseInt(final.innerHTML, 10) || 0;
            final.innerHTML = totalActuel + (achatUnite.checked ? total : totalcageot);
            let somes = somes + quantite;
            console.log(somes);
            let newRow = `<tr data-total="${achatUnite.checked ? total : totalcageot}" data-id="${articleId}">
                <td>${articleNom}</td>
                <td>${prix} Ar</td>
                <td>${prix + prix_consignation} Ar</td>
                <td>${quantite} ${achatUnite.checked ? 'bouteille' : 'cageot (' + conditionnement + ' bouteilles / CGT)'}</td>
                <td>${cgt_checkbox.checked ? 'oui (non consigné)' : 'non(3000 ar  / CGT)'}</td>
                <td>${avec.checked ? 'oui' : 'non'}</td>
                <td>${consignation} ${non.checked ? '' : prix_consignation + ' Ar/BTL'}</td>
                <td>${achatUnite.checked ? total : totalconsignecageot} Ar</td>
                <td><button type="button" class="btn btn-danger btn-sm removeArticle">X</button></td>
            </tr>`;

            document.getElementById('articlesTable').insertAdjacentHTML('beforeend', newRow);

            let hiddenInputs = document.getElementById('hiddenInputs');
            hiddenInputs.insertAdjacentHTML('beforeend', `
                <div class="hidden-group" data-id="${articleId}">
                    <input type="hidden" name="articles[]" value="${articleId}">
                    <input type="hidden" name="quantites[]" value="${quantite}">
                    <input type="hidden" name="prices[]" value="${prix}">
                    <input type="hidden" name="dateventes[]" value="${datevente}">
                    <input type="hidden" name="types[]" value="${types}">
                    <input type="hidden" name="consignations[]" value="${unite.checked ? '1' : '0'}">
                    <input type="hidden" name="bouteilles[]" value="${avec.checked ? '1' : '0'}">
                    <input type="hidden" name="cageots[]" value="${cgt_checkbox.checked ? '1' : '0'}">
                    <input type="hidden" name="unites" value="${unite.checked ? '1' : '0'}">
                </div>
            `);
        });

        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('removeArticle')) {
                let row = e.target.closest('tr');
                let totalRow = parseInt(row.getAttribute('data-total'), 10) || 0;
                let articleId = row.getAttribute('data-id');

                // Supprimer la ligne du tableau
                row.remove();

                // Mettre à jour le total final
                let totalActuel = parseInt(final.innerHTML, 10) || 0;
                final.innerHTML = totalActuel - totalRow;

                // Supprimer les inputs cachés associés
                let hiddenGroup = document.querySelector(`.hidden-group[data-id="${articleId}"]`);
                if (hiddenGroup) {
                    hiddenGroup.remove();
                }
            }
        });

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/vente/Liste.blade.php ENDPATH**/ ?>