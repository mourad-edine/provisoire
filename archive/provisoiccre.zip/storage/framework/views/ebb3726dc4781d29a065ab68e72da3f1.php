

<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">VENTE</h1>
    <p class="mb-4">Details de la commande</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary"><a href="<?php echo e(route('vente.liste')); ?>">Listes ventes</a> --- <a href="<?php echo e(route('commande.liste.vente')); ?>">Listes par commandes</a></h6>
            <div class="d-flex justify-content-end">
                <button class="btn btn-secondary btn-sm mr-3"> <a class="text-white" href="<?php echo e(route('pdf.download',['id' => $commande_id])); ?>"><i class="fas fa-print text-white mr-2"></i>facture</a></button>
                <button class="btn btn-primary btn-sm"><a class="text-white" href="<?php echo e(route('commande.liste.vente')); ?>">retour</a></button>

            </div>
        </div>
        <div class="card-body">

        <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Désignation</th>
                            <th>commande</th>
                            <th>consignation</th>
                            <th>état</th>
                            <th>Quantité</th>
                            <!-- <th>(P.U)</th> -->
                            <th>(P.Consigné)</th>
                            <th>total</th>
                            <th>Date vente</th>
                            <th>Options</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($vente['id']); ?></td>
                            <td><?php echo e($vente['article']); ?></td>
                            <td>C-<?php echo e($vente['numero_commande']); ?></td>
                            <td><?php echo e($vente['consignation'] ? $vente['consignation'] .' Ar': 'non consigné'); ?></td>
                            <td><?php echo e($vente['etat']); ?></td>
                            <td><?php echo e($vente['quantite']); ?> <?php echo e($vente['type_achat']); ?></td>
                            <!-- <td><?php echo e($vente['prix_unitaire']); ?> Ar</td> -->
                            <td><?php echo e($vente['prix_unitaire'] + $vente['prix_consignation']); ?> Ar</td>
                            <td>
                                <?php if($vente['type_achat'] === 'cageot'): ?>
                                <?php echo e(($vente['prix_unitaire'] + $vente['prix_consignation']) * $vente['quantite'] * $vente['conditionnement']); ?>Ar
                                <?php else: ?>
                                <?php echo e(($vente['prix_unitaire'] + $vente['prix_consignation']) * $vente['quantite']); ?> Ar
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($vente['created_at']); ?></td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="<?php echo e(route('pdf.download' , ['id'=>$commande_id])); ?>"><i class="fas fa-print text-warning"></i></a>
                               
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-warning">Pas encore de données insérées pour le moment</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script>

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views\pages\vente\Detail.blade.php ENDPATH**/ ?>