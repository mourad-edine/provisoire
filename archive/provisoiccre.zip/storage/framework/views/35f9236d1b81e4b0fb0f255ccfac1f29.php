<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">BOISSON</h1>
    <p class="mb-4">Ajouter votre article.</p>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Liste des boissons</h6>
            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addArticleModal">Ajouter Boisson</button>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Catégorie</th>
                            <th>Prix Unitaire (PU)</th>
                            <th>Prix Cageot (P.C)</th>
                            <th>Quantité</th>
                            <th>Date de Création</th>
                            <th>Options</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($article['id']); ?></td>
                            <td><?php echo e($article['nom']); ?></td>
                            <td><?php echo e($article['categorie']); ?></td>
                            <td><?php echo e($article['prix_unitaire']); ?> Ar</td>
                            <td><?php echo e($article['prix_conditionne'] ? $article['prix_conditionne'] : 'pas encore de prix'); ?></td>
                            <td><?php echo e($article['quantite']); ?></td>
                            <td><?php echo e($article['created_at']); ?></td>
                            <td>
                                <a href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-edit"></i></a>
                                <form action="#" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" style="background:none; border:none; color:red;"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center text-warning">Pas encore de données insérées pour le moment</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-start mt-3">
                    <?php echo e($articles->links('pagination::bootstrap-4')); ?> <!-- Ou 'pagination::bootstrap-5' -->
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Modal d'ajout d'article -->
<div class="modal fade" id="addArticleModal" tabindex="-1" aria-labelledby="addArticleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addArticleModalLabel">Ajouter un article</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('articles.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nom">Nom</label>
                        <input type="text" class="form-control" id="nom" name="nom" required>
                    </div>
                    <div class="">
                        <div class="form-group">
                            <label for="categorie">categorie</label>
                            <select class="form-control" id="categorie" name="categorie_id">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->nom); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="">
                        <div class="form-group">
                            <label for="conditionnement">conditionnement</label>
                            <select class="form-control" id="conditionnement" name="conditionnement" >
                                <option value="20">---selectionner--</option>
                                <option value="20">cageot de 20</option>
                                <option value="24">cageot de 24</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="prix_unitaire">Prix d'achat</label>
                        <input type="number" class="form-control" id="prix_vente" name="prix_vente" required>
                    </div>
                    <div class="form-group">
                        <label for="prix_unitaire">Prix de vente</label>
                        <input type="number" class="form-control" id="prix_unitaire" name="prix_unitaire" required>
                    </div>
                    
                    <div class="form-group">
                        <input type="checkbox" id="checkCageot" name="checkCageot">
                        <label for="checkCageot">Ajouter un prix en cageot</label>
                    </div>
                    <div class="form-group" id="prixCageotContainer" style="display:none;">
                        <label for="prix_conditionne">Prix en Cageot</label>
                        <input type="number" class="form-control" id="prix_conditionne" name="prix_conditionne">
                    </div>
                    <div class="form-group">
                        <label for="quantite">Quantité en cageot (facultatif <span style="color: red;">*</span> )</label>
                        <input type="number" class="form-control" id="quantite" name="quantite">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Ajouter</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('checkCageot').addEventListener('change', function() {
        document.getElementById('prixCageotContainer').style.display = this.checked ? 'block' : 'none';
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/article/Liste.blade.php ENDPATH**/ ?>