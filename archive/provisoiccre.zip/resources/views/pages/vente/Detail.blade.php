@extends('layouts.AdminLayout')

@section('title', 'Accueil')

@section('content')
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">VENTE</h1>
    <p class="mb-4">Details de la commande</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <div class="d-flex">
                <a href="{{route('vente.liste')}}" class="btn btn-outline-primary btn-sm font-weight-bold mr-2 px-3 shadow-sm">Listes ventes</a>
                <a href="{{route('commande.liste.vente')}}" class="btn btn-outline-success btn-sm font-weight-bold px-3 shadow-sm">Listes par commandes</a>
            </div>
            <div class="d-flex justify-content-end">
                <button class="btn btn-secondary btn-sm mr-3"> <a class="text-white" href="{{route('pdf.download',['id' => $commande_id])}}"><i class="fas fa-print text-white mr-2"></i>facture</a></button>
                <button class="btn btn-primary btn-sm"><a class="text-white" href="{{route('commande.liste.vente')}}">retour</a></button>

            </div>
        </div>
        <div class="card-body">

        <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Art.</th>
                            <th>commande</th>
                            <th>consi(CGT/BTL)</th>
                            <th>état BTL</th>
                            <th>état CGT</th>
                            <th>état</th>
                            <th>Quantité</th>
                            <!-- <th>(P.U)</th> -->
                            <th>(Prix)</th>
                            <th>total</th>
                            <th>Date vente</th>
                            <th>Options</th>
                        </tr>
                    </thead>

                    <tbody>
                        @forelse($ventes as $vente)
                        <tr>
                            <td>{{$vente['id']}}</td>
                            <td>{{$vente['article']}}</td>
                            <td>C-{{$vente['numero_commande']}}</td>
                            <td>
                                @if($vente['consignation'] && $vente['prix_cgt'])
                                {{$vente['consignation'] + $vente['prix_cgt']}} Ar
                                @elseif($vente['consignation'])
                                {{$vente['consignation']}} Ar
                                @elseif($vente['prix_cgt'])
                                {{$vente['prix_cgt']}} Ar
                                @else
                                non consi°
                                @endif
                            </td>
                            <td>
                                <span class="{{ $vente['etat'] == 'non rendu' ? 'text-danger' : '' }}">
                                    {{ $vente['etat'] ?? 'non consi°' }}
                                </span>
                            </td>
                            <td>
                                <span class="{{ $vente['etat_cgt'] == 'non rendu' ? 'text-danger' : '' }}">
                                    {{ $vente['etat_cgt'] ?? 'non consi°' }}
                                </span>
                            </td>
                            <td>
                                <p class="text-success">payé</p>
                            </td>
                            <td>{{$vente['quantite']}} {{$vente['type_achat']}}</td>
                            <!-- <td>{{$vente['prix_unitaire']}} Ar</td> -->
                            <td>{{$vente['btl'] == 0 ? $vente['prix_unitaire'] + $vente['prix_consignation'] : $vente['prix_unitaire']}} Ar</td>
                            <!-- <td>
                                @php
                                if($vente['type_achat'] == 'bouteille'){
                                    $prix_total = $vente['prix_unitaire'] * $vente['quantite'];
                                    if($vente['cgt'] == 0 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'] + $vente['prix_cgt'];
                                    }else if($vente['cgt'] == 1 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'];
                                    }else if($vente['cgt']== 0 && $vente['btl'] == 1){
                                        $prix_total += $vente['prix_cgt'];
                                    }else{
                                        $prix_total += 0;
                                    }
                                }else if ($vente['type_achat'] === 'cageot') {
                                    $prix_total = $vente['prix_unitaire'] * $vente['quantite'] * $vente['conditionnement'];
                                    if($vente['cgt'] == 0 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'] + $vente['prix_cgt'];
                                    }else if($vente['cgt'] == 1 && $vente['btl'] == 0){
                                        $prix_total += $vente['consignation'];
                                    }else if($vente['cgt']== 0 && $vente['btl'] == 1){
                                        $prix_total += $vente['prix_cgt'];
                                    }else{
                                        $prix_total += 0;
                                    }
                                }
                                @endphp

                                {{ $prix_total }} Ar
                            </td> -->
                            <td>
                                @php
                                $prix_total = $vente['prix_unitaire'] * $vente['quantite'];

                                if ($vente['type_achat'] === 'cageot') {
                                $prix_total *= $vente['conditionnement'];
                                }

                                // Gestion des frais supplémentaires en fonction de cgt et btl
                                $prix_total += match (true) {
                                $vente['cgt'] == 0 && $vente['btl'] == 0 => $vente['consignation'] + $vente['prix_cgt'],
                                $vente['cgt'] == 1 && $vente['btl'] == 0 => $vente['consignation'],
                                $vente['cgt'] == 0 && $vente['btl'] == 1 => $vente['prix_cgt'],
                                default => 0,
                                };
                                @endphp

                                {{ number_format($prix_total, 0, ',', ' ') }} Ar
                            </td>

                            <td>{{ \Carbon\Carbon::createFromTimestamp($vente['created_at'])->format('d-m-Y') }}</td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-edit"></i></a>
                                <a target="_blank" href="{{ route('pdf.download', ['id'=> $commande_id]) }}"><i class="fa fa-archive" aria-hidden="true"></i></i></a>

                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="8" class="text-warning">Pas encore de données insérées pour le moment</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
                <div class="d-flex justify-content-start mt-3">
                    {{ $ventes->links('pagination::bootstrap-4') }} <!-- ou 'pagination::bootstrap-5' -->
                </div>
            </div>
            <div class="table-responsive">
                <p>Conditionnement</p>
                <hr>
                <img src="{{asset('assets/images/enter.png')}}" alt="" width="40" height="40">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    @if($conditionnement != null)
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Prix Cageot</th>
                            <th>Nombre Cageot</th>
                            <th>Total</th>
                            <th>État</th>
                            <th>État CGT</th>
                            <th>option</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td>{{ $conditionnement->id }}</td>
                            <td>3000 Ar/CGT</td>
                            <td>{{ optional($conditionnement->conditionnement)->nombre_cageot. ' CGT' ?? 'non conditionné'}}</td>
                            <td>{{ optional($conditionnement->conditionnement)->nombre_cageot * 3000  ?? 'non conditionné' }} Ar</td>
                            <td>{{ optional($conditionnement->conditionnement)->etat ?? 'non conditionné' }}</td>
                            <td>{{ optional($conditionnement->conditionnement)->created_at  ?? 'non conditionné' }}</td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="{{route('pdf.download' , ['id'=>$commande_id])}}"><i class="fas fa-edit text-warning"></i></a>

                            </td>
                        </tr>
                    </tbody>
                    @else
                    <tbody>
                        <tr>
                            <td colspan="6" class="text-warning text-center">Non conditionné</td>
                        </tr>
                    </tbody>
                    @endif
                </table>

            </div>
        </div>
    </div>

</div>

<script>

</script>

@endsection