

<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->

    <!-- DataTales Example -->


    <ul class="nav nav-tabs" id="parametresTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <a style="text-decoration: none;" href="<?php echo e(route('vente.liste')); ?>">
                <button class="nav-link active" id="consignation-tab" data-bs-toggle="tab" data-bs-target="#consignation" type="button" role="tab" aria-controls="consignation" aria-selected="true">
                    <i class="fas fa-wine-bottle me-2"></i>Listes ventes
                </button>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a style="text-decoration: none;" href="<?php echo e(route('commande.liste.vente')); ?>">
                <button class="nav-link" id="utilisateur-tab" data-bs-toggle="tab" data-bs-target="#utilisateur" type="button" role="tab" aria-controls="utilisateur" aria-selected="false">
                    <i class="fas fa-user me-2"></i>Listes par commandes
                </button>
            </a>
        </li>
    </ul>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center bg-secondary border-bottom">
            <h5 class="mb-2 text-white">VENTE - DETAILS</h5>

            <div class="d-flex justify-content-end">
                <button class="btn btn-outline-warning btn-sm mr-3"> <a class="text-white" href="<?php echo e(route('pdf.download',['id' => $commande_id])); ?>"><i class="fas fa-print text-white mr-2"></i>facture</a></button>
                <button class="btn btn-primary btn-sm"><a class="text-white" href="<?php echo e(route('commande.liste.vente')); ?>">retour</a></button>

            </div>
        </div>

        <div class="card-body">

            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle" id="dataTable" width="100%" cellspacing="0">
                    <thead class="table-light">
                        <tr>
                            <th class="bg-light">ID</th>
                            <th>Article</th>
                            <th>Commande</th>
                            <th>Consi(CGT/BTL)</th>
                            <th>État BTL</th>
                            <th>État CGT</th>
                            <th>Statut</th>
                            <th>Quantité</th>
                            <th>prix</th>
                            <th>Total</th>
                            <th>Date</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $highlightedId = session('highlighted_id'); ?>
                        <?php
                        $bouteilleNonRendu = $vente['etat'] == 'non rendu';
                        $cageotNonRendu = $vente['etat_cgt'] == 'non rendu';
                        ?>
                        <tr id="row-<?php echo e($vente['id']); ?>" class="<?php echo e($highlightedId == $vente['id'] ? 'table-info' : ''); ?>">
                            <td class="fw-semibold"><?php echo e($vente['id']); ?></td>
                            <td><?php echo e($vente['article']); ?></td>
                            <td class="text-primary fw-semibold">C-<?php echo e($vente['numero_commande']); ?></td>
                            <td>
                                <?php if($vente['consignation'] || $vente['prix_cgt']): ?>
                                <span class="badge bg-light text-dark border">
                                    <?php echo e(number_format(($vente['consignation'] ?? 0) + ($vente['prix_cgt'] ?? 0), 0, ',', ' ')); ?> Ar
                                </span>
                                <?php else: ?>
                                <span class="badge bg-light text-muted border">Non consigné</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($vente['etat'] == 'non rendu' ? 'bg-danger text-white' : 'bg-success-subtle text-white'); ?>">
                                    <?php echo e($vente['etat'] ?? 'Non consigné'); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo e($vente['etat_cgt'] == 'non rendu' || $vente['etat_cgt'] == 'conditionné' ? 'bg-danger text-white' : 'bg-success text-white'); ?>">
                                    <?php echo e($vente['etat_cgt'] ?? 'Non consigné'); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge bg-success-subtle text-success">
                                    <i class="fas fa-check-circle me-1"></i> Payé
                                </span>
                            </td>
                            <td class="fw-semibold"><?php echo e($vente['quantite']); ?> <?php echo e($vente['type_achat']); ?></td>
                            <td class="text-nowrap"><?php echo e(number_format($vente['btl'] == 0 ? $vente['prix_unitaire'] + $vente['prix_consignation'] : $vente['prix_unitaire'], 0, ',', ' ')); ?> Ar</td>
                            <td class="fw-bold text-nowrap"><?php echo e(number_format($vente['prix_unitaire'] * $vente['quantite'], 0, ',', ' ')); ?> Ar</td>
                            <td class="text-muted"><?php echo e(optional($vente['created_at'])->format('d/m/Y')); ?></td>
                            <td>
                                <!-- Icônes d'options -->
                                <a class="ml-3" href="#" data-toggle="modal" data-target="#venteModal2<?php echo e($vente['id']); ?>"><i class="fas fa-edit text-warning"></i></a>

                            </td>
                        </tr>
                        <!-- modal commencement -->
                        <!-- Modal pour le paiement de la consignation -->
                        <div class="modal fade" id="venteModal2<?php echo e($vente['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="venteModal2Label" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <!-- En-tête du modal -->
                                    <div class="modal-header bg-light">
                                        <h5 class="modal-title" id="venteModal2Label">Rendre consignation</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Fermer">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>

                                    <!-- Formulaire de paiement -->
                                    <form action="<?php echo e(route('payer.consignation')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <!-- Corps du modal -->
                                        <div class="modal-body">
                                            <div class="row">
                                                <!-- Section Bouteille -->
                                                <div class="col-md-12 mb-3">
                                                    <div class="form-group d-flex align-items-center">
                                                        <input type="hidden" value="<?php echo e($vente['id']); ?>" name="vente_id">
                                                        <?php if($vente['etat'] == 'non rendu'): ?>
                                                        <input type="checkbox" name="check_bouteille" id="check_bouteille<?php echo e($vente['id']); ?>" class="mr-2">
                                                        <label for="check_bouteille<?php echo e($vente['id']); ?>" class="mb-0 cursor-pointer">
                                                            Bouteille - <span><?php echo e($vente['consignation']); ?> Ar</span>
                                                        </label>
                                                        <?php elseif($vente['etat'] == 'avec BTL'): ?>
                                                        <label class="mb-0 cursor-pointer">
                                                            Bouteille <span class="text-success">non consigné</span>
                                                        </label>
                                                        <?php else: ?>
                                                        <label class="mb-0 cursor-pointer">
                                                            <span class="text-success">Bouteille rendu</span>
                                                        </label>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>

                                                <!-- Section Cageot -->
                                                <div class="col-md-12 mb-3">
                                                    <div class="form-group d-flex align-items-center">
                                                        <input type="hidden" value="<?php echo e($vente['consignation_id']); ?>" name="consignation_id">
                                                        <?php if($vente['etat_cgt'] == 'non rendu'): ?>
                                                        <input type="checkbox" name="check_cageot" id="check_cageot<?php echo e($vente['id']); ?>" class="mr-2">
                                                        <label for="check_cageot<?php echo e($vente['id']); ?>" class="mb-0 cursor-pointer">
                                                            <span>Cageot <?php echo e($vente['prix_cgt']); ?> Ar</span>
                                                        </label>
                                                        <?php elseif($vente['etat_cgt'] == 'avec CGT' || $vente['etat_cgt'] == 'non condi°'): ?>
                                                        <label class="mb-0 cursor-pointer">
                                                            <span class="text-success">Cageot non consigné</span>
                                                        </label>
                                                        <?php elseif($vente['etat_cgt'] == 'conditionné'): ?>
                                                        <label class="mb-0 cursor-pointer">
                                                            <span class="text-danger">Bouteilles conditionné en cageot (cliquer en bas pour rendre)</span>
                                                        </label>
                                                        <?php else: ?>
                                                        <label class="mb-0 cursor-pointer">
                                                            <span class="text-success">Cageot payé</span>
                                                        </label>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Pied du modal -->
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>

                                            <?php if($vente['etat'] == 'non rendu' || $vente['etat_cgt'] == 'non rendu'): ?>
                                            <!-- Afficher le bouton "Payer" si la bouteille ou le cageot est "non rendu" -->
                                            <button type="submit" class="btn btn-primary">Payer</button>
                                            <?php else: ?>
                                            <!-- Désactiver ou masquer le bouton "Payer" si aucun paiement n'est nécessaire -->
                                            <button type="button" class="btn btn-primary" disabled>Payer</button>
                                            <!-- Ou pour masquer complètement le bouton : -->
                                            <!-- <button type="submit" class="btn btn-primary d-none">Payer</button> -->
                                            <?php endif; ?>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- modal fin -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-warning">Pas encore de données insérées pour le moment</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-start mt-3">
                    <?php echo e($ventes->links('pagination::bootstrap-4')); ?> <!-- ou 'pagination::bootstrap-5' -->
                </div>
            </div>
            <div class="table-responsive">
                <p>Conditionnement</p>
                <hr>
                <img src="<?php echo e(asset('assets/images/enter.png')); ?>" alt="" width="20" height="20">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <?php if($conditionnement != null): ?>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Prix Cageot</th>
                            <th>Nombre Cageot</th>
                            <th>Total</th>
                            <th>État</th>
                            <th>État CGT</th>
                            <th>option</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td><?php echo e(optional($conditionnement->conditionnement)->id ? optional($conditionnement->conditionnement)->id : 'non conditionné'); ?></td>
                            <td><?php echo e(optional($conditionnement->conditionnement)->nombre_cageot ? '3000 Ar/CGT' : 'non conditionné'); ?></td>
                            <td><?php echo e(optional($conditionnement->conditionnement)->nombre_cageot ?  optional($conditionnement->conditionnement)->nombre_cageot. ' CGT' : 'non conditionné'); ?></td>
                            <td><?php echo e(optional($conditionnement->conditionnement)->nombre_cageot ? optional($conditionnement->conditionnement)->nombre_cageot * 3000 .'Ar':'non conditionné'); ?> </td>
                            <td><?php echo e(optional($conditionnement->conditionnement)->etat ?? 'non conditionné'); ?></td>
                            <td><?php echo e(optional($conditionnement->conditionnement)->created_at  ?? 'non conditionné'); ?></td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="#"><i class="fas fa-edit text-warning"></i></a>

                            </td>
                        </tr>
                    </tbody>
                    <?php else: ?>
                    <tbody>
                        <tr>
                            <td colspan="6" class="text-warning text-center">Non conditionné</td>
                        </tr>
                    </tbody>
                    <?php endif; ?>
                </table>

            </div>
        </div>
    </div>

</div>

<script>

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views\pages\vente\Detail.blade.php ENDPATH**/ ?>