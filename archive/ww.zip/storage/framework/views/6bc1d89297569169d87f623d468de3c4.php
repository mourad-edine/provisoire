<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facture</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: rgb(0 0 0 / 80%)
        }

        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .total {
            font-weight: bold;
            font-size: 18px;
            text-align: right;
            padding-top: 10px;
        }

        .contain {
            width: 100%;
            margin-top: 30px;
        }

        .contain div {
            display: inline-block;
            width: 32%;
            vertical-align: top;
        }

        .left {
            text-align: left;
        }

        .center {
            text-align: start;
        }

        .right {
            text-align: start;
        }

        .final {
            margin-left: 40px;;
        }

        .summary-section {
            margin-top: 30px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
        }



    </style>
</head>

<body>

    <div class="header">Facture DO-09D32001/15714/25</div>

    <div class="contain">
        <div class="left">
            <strong>Distributeur :</strong><br>
            Nom : Entreprise ABC<br>
            Adresse : 123 Rue Marché, Antananarivo<br>
            Contact : +261 34 12 345 67
        </div>

        <div class="right">
            <strong>Client :</strong><br>
            Nom : Jean Dupont<br>
            Adresse : 456 Rue Client, Antananarivo<br>
            Contact : +261 32 45 678 90
        </div>
    </div>
    <div class="contain">
        <div class="center">
            <strong>Date de commande :</strong><br>
            <?php echo e(\Carbon\Carbon::parse($achats->first()->created_at)->format('d/m/Y')); ?>

        </div>
    </div>
    <table>
        <thead>
            <tr>
                <th>commande</th>
                <th>Prix / cageot</th>
                <th>Quantité</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $achats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($achat->articles ? $achat->articles->nom : '-'); ?></td>
                <td><?php echo e(number_format($achat->prix / $achat->quantite, 2)); ?> Ar</td>
                <td><?php echo e($achat->quantite); ?></td>
                <td><?php echo e(number_format($achat->prix, 2)); ?> Ar</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="summary-section">
        <div class="summary-row">
            <span class=""><strong>Montant liquide</strong> : </span>______________________________________________
            <span class=""><?php echo e(number_format($total, 2, ',', ' ')); ?> Ar</span>
        </div>
    </div>
    <div class="fin">
        <div class="">
            <span class="">Total TTC</span>
            <span class="">186 413 512 Ar</span>
        </div>

        <div class="">
            <span class="">Total quantité commande</span>
            <span class="">32 cgt</span>
        </div>
    </div>


</body>

</html><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/pdf/facture.blade.php ENDPATH**/ ?>