<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="">

    <!-- Navigation Tabs -->
    <ul class="nav nav-tabs mb-4" id="parametresTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('commande.liste.vente')); ?>">
                <button class="nav-link" id="commandes-tab">
                    <i class="fas fa-list-alt me-2"></i> Listes par commandes
                </button>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('vente.liste')); ?>">
                <button class="nav-link active">
                    <i class="fas fa-shopping-cart me-2"></i> Listes ventes
                </button>
            </a>
        </li>
        <!-- <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('paiment.all')); ?>">
                <button class="nav-link">
                    <i class="fas fa-history me-2"></i> Historique des paiements
                </button>
            </a>
        </li> -->
       
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('vente.page')); ?>">
                <button class="nav-link active bg-dark text-white">
                    <i class="fas fa-cart-plus me-2 text-white"></i> Nouvel vente
                </button>
            </a>
        </li>
    </ul>

    <!-- Main Card -->
    <div class="card shadow-sm">
        <!-- Card Header -->
        

        <!-- Card Body -->
        <div class="card-body p-4">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <!-- Ventes Table -->
            <div class="table-responsive mb-4">
                <table class="table table-bordered table-hover" id="dataTable">
                    <thead class="table-secondary">
                        <tr>
                            <th>ID</th>
                            <th>Article</th>
                            <th>CGT/BTL</th>
                            <th>BTL</th>
                            <th>CGT</th>
                            <th>Statut</th>
                            <th>Quantité</th>
                            <th>Prix</th>
                            <th>Total</th>
                            <th>Bénéfice</th>

                            <th class="text-end">details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $prixGlobale = 0;$deconsigneglobale = 0 ; $totalconsigne = 0; $totalbtl = 0; $totalcgt = 0; $casse = 0 ; $casse_cgt = 0 ;$rendu_btl=0 ; $rendu_cgt = 0; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                        $highlightedId = session('highlighted_id');
                        $bouteilleNonRendu = $vente['etat'] == 'non rendu';
                        $cageotNonRendu = $vente['etat_cgt'] == 'non rendu';
                        ?>

                        <tr id="row-<?php echo e($vente['id']); ?>" class="<?php echo e($highlightedId == $vente['id'] ? 'bg-info' : ''); ?>">
                            <td class="fw-bold"><?php echo e($vente['id']); ?></td>
                            <td><?php echo e($vente['article']); ?></td>
                            <td>
                                <?php if(($vente['consignation'] ?? 0) + ($vente['prix_cgt'] ?? 0) > 0): ?>
                                <?php if($vente['etat_client'] == 1): ?>
                                <span class="badge bg-danger text-white">à rendre</span>
                                <?php elseif($vente['etat_client_commande'] == 2 ): ?>
                                <span class="badge bg-warning">à disposition</span>
                                <?php else: ?>
                                <span class="badge bg-light text-dark">
                                    <?php echo e(number_format(($vente['consignation'] ?? 0) + ($vente['prix_cgt'] ?? 0), 0, ',', ' ')); ?> Ar
                                </span>
                                <?php endif; ?>
                                <?php else: ?>
                                <span>--</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($vente['etat'] == 'non rendu' ? 'bg-danger text-white' : 'bg-success text-white'); ?>">
                                    <?php echo e($vente['etat'] ?($vente['prix_consignation'] == 0 ? 0 : $vente['consignation'] / $vente['prix_consignation']) : '--'); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo e(in_array($vente['etat_cgt'], ['non rendu']) ? 'bg-danger text-white' : 'bg-success text-white'); ?>">
                                    <?php echo e($vente['etat_cgt'] ?($vente['consi_cgt'] == 0 ? 0 : $vente['prix_cgt'] / $vente['consi_cgt']):'--'); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo e($vente['etat_payement'] == 0 ? 'bg-danger-light text-danger' : 'bg-success-light text-success'); ?>">
                                    <i class="fas <?php echo e($vente['etat_payement'] == 0 ? 'fa-times-circle text-danger' : 'fa-check-circle text-success'); ?> me-1"></i>
                                    <?php echo e($vente['etat_payement'] == 0 ? '' : ''); ?>

                                </span>
                            </td>
                            <td class="fw-bold"><?php echo e($vente['quantite']); ?> <?php echo e($vente['type_achat']); ?></td>
                            <td>
                                <?php echo e(number_format($vente['prix_unitaire'], 0, ',', ' ')); ?> Ar
                                <?php if (! ($vente['etat_client'] == 1 || $vente['etat'] == 'rendu' || $vente['etat'] == 'non consigné' || !isset($vente['etat']))): ?>
                                + <?php echo e(number_format($vente['prix_consignation'], 0, ',', ' ')); ?> Ar
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php
                                $prix_total = ($vente['type_achat'] === 'cageot' || $vente['type_achat'] === 'pack')
                                ? ($vente['prix_unitaire'] * $vente['quantite'] * $vente['conditionnement']) + $vente['consignation'] + $vente['prix_cgt']
                                : ($vente['prix_unitaire'] * $vente['quantite']) + $vente['consignation'] + $vente['prix_cgt'];

                                
                                
                                ?>

                                <?php echo e(number_format($prix_total, 0, ',', ' ')); ?> Ar
                            </td>
                            <td> -- </td>

                            <td class="text-end">
                                <?php if($vente['etat_client_commande'] != 2): ?>
                                <a href="<?php echo e(route('commande.liste.vente.detail', ['id' => $vente['numero_commande']])); ?>" class="text-primary">
    <i class="fas fa-edit"></i>
</a>

                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- Modal for each vente -->
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">
                                <i class="fas fa-exclamation-circle me-2"></i>Aucune donnée disponible
                            </td>
                        </tr>
                        <?php endif; ?>

                        <!-- Total Row -->
                        
                       
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="d-flex justify-content-start mt-3">
                    <?php echo e($ventes->links('pagination::bootstrap-4')); ?>

                </div>
                
            </div>

            <!-- Conditionnement Section -->
            <div class="mt-4">
                <!-- <h5 class="d-flex align-items-center text-uppercase fw-bold mb-3">
                    <img src="<?php echo e(asset('assets/images/enter.png')); ?>" alt="Conditionnement" width="24" class="me-2">
                    Conditionnement
                </h5> -->
                <hr class="mt-0">

               

                <!-- Global Total -->

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mourad/Documents/provisoire/resources/views/pages/vente/Liste.blade.php ENDPATH**/ ?>