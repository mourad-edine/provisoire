

<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<style>
    a{
        color: #333;
    }
    a:hover{
        color: #333;
    }
</style>
<div class="container-fluid px-3 py-4">

    <!-- Navigation Tabs -->
    <ul class="nav nav-tabs mb-4" id="parametresTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <a href="<?php echo e(route('commande.liste.vente')); ?>" class="nav-link">
                <i class="fas fa-list-alt me-2"></i>Listes par commandes
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a href="<?php echo e(route('vente.liste')); ?>" class="nav-link active">
                <i class="fas fa-shopping-cart me-2"></i>Listes ventes
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a href="<?php echo e(route('vente.liste')); ?>" class="nav-link">
                <i class="fas fa-history me-2"></i>Historique des paiements
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a href="<?php echo e(route('rendre.boissons', ['id' => $commande_id])); ?>" class="nav-link">
                <i class="fas fa-file-alt me-2"></i>Compte rendu
            </a>
        </li>
    </ul>

    <!-- Card Principal -->
    <div class="card shadow">
        <div class="card-header d-flex justify-content-between align-items-center bg-secondary text-white">
            <h5 class="mb-0 text-white">VENTE - COMPTE-RENDU</h5>
            <div>
                <a href="<?php echo e(route('commande.liste.vente.detail', ['id' => $commande_id])); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-arrow-left me-1 text-white"></i>Retour
                </a>
            </div>
        </div>
        <div class="card-body">

            <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <!-- Table Vente -->
            <form action="<?php echo e(route('rendre.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="client_id" value="<?php echo e($client_id); ?>">
                <input type="hidden" name="commande_id" value="<?php echo e($commande_id); ?>">
                <div class="table-responsive mb-4">
                    <table class="table table-bordered">
                        <thead class="table-secondary">
                            <tr>
                                <th class="text-end">Sélectionner</th>
                                <th>ID</th>
                                <th>Article</th>
                                <th>Quantité</th>
                                <th>Bouteilles</th>
                                <th>Cageot/Pack</th>
                                <th>unité</th>
                                <th>État</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="text-end">
                                    <input type="checkbox" name="check[<?php echo e($vente->id); ?>]" checked>
                                    <input type="hidden"
                                                class="form-control form-control-sm"
                                                value="<?php echo e(optional($vente->article)->id); ?>"
                                                name="article_id[<?php echo e($vente->id); ?>]"
                                                required
                                                >
                                </td>
                                <td><?php echo e($vente->id); ?></td>
                                <td><?php echo e(optional($vente->article)->nom ?? '—'); ?></td>
                                <td><?php echo e($vente->quantite); ?> - <?php echo e($vente->type_achat); ?></td>

                                <td>
                                    <input type="number" step="1" min="0"
                                        name="bouteilles[<?php echo e($vente->id); ?>]"
                                        id="bouteilles_<?php echo e($vente->id); ?>"
                                        class="form-control form-control-sm bouteilles-input"
                                        data-conditionnement="<?php echo e(optional($vente->article)->conditionnement); ?>"
                                        data-id="<?php echo e($vente->id); ?>"
                                        max="<?php echo e($vente->type_achat == 'cageot' ? $vente->quantite * optional($vente->article)->conditionnement : $vente->quantite); ?>"
                                        oninput="updateCageots(this)"
                                        readonly>
                                </td>
                                <td>
                                    <input type="number" step="1" min="0"
                                        name="cageots[<?php echo e($vente->id); ?>]"
                                        id="cageots_<?php echo e($vente->id); ?>"
                                        class="form-control form-control-sm cageots-input"
                                        data-conditionnement="<?php echo e(optional($vente->article)->conditionnement); ?>"
                                        data-id="<?php echo e($vente->id); ?>"
                                        max="<?php echo e($vente->quantite); ?>"
                                        oninput="updateBouteilles(this)"
                                        <?php echo e($vente->type_achat == 'bouteille' ? 'readonly' : ''); ?>

                                        >
                                </td>
                                <!-- <td><?php echo e(optional($vente->commande)->etat_commande ?? '—'); ?></td> -->
                                 <td>
                                    <input type="hidden" value="<?php echo e($commande_id); ?>" name="commande_id">
                                 <input type="number" step="1" min="0"
                                        name="unite[<?php echo e($vente->id); ?>]"
                                        class="form-control form-control-sm cageots-input"
                                        max="<?php echo e($vente->type_achat == 'bouteille' ? $vente->quantite : $vente->article->conditionnement - 1); ?>"
                                        placeholder="0"
                                        >
                                 </td>
                                 <td>
                                <?php echo e(optional($vente->commande)->etat_commande ?? '—'); ?>


                                 </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">Aucune vente enregistrée.</td>
                            </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
                <!-- Bouton de soumission -->
                <div class="text-end">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save me-1 text-white"></i> Enregistrer les modifications
                    </button>
                </div>
            </form>

        </div>
    </div>
</div>

<script>
    function updateCageots(input) {
        const id = input.getAttribute('data-id');
        const conditionnement = parseFloat(input.getAttribute('data-conditionnement')) || 1;
        const bouteillesValue = parseFloat(input.value) || 0;
        
        const cageotsInput = document.getElementById(`cageots_${id}`);
        let cageotsValue = bouteillesValue / conditionnement;
        
        // Si la valeur est inférieure à 1, on met 0
        // Sinon on prend la partie entière (floor)
        cageotsValue = cageotsValue < 1 ? 0 : Math.floor(cageotsValue);
        
        cageotsInput.value = cageotsValue;
    }

    function updateBouteilles(input) {
        const id = input.getAttribute('data-id');
        const conditionnement = parseFloat(input.getAttribute('data-conditionnement')) || 1;
        const cageotsValue = parseFloat(input.value) || 0;
        
        const bouteillesInput = document.getElementById(`bouteilles_${id}`);
        const bouteillesValue = cageotsValue * conditionnement;
        
        bouteillesInput.value = bouteillesValue % 1 === 0 ? bouteillesValue : bouteillesValue.toFixed(2);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mourad/Documents/provisoire/resources/views/pages/vente/Rendre.blade.php ENDPATH**/ ?>