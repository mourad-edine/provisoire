

<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="">

    <!-- Navigation Tabs -->
    <ul class="nav nav-tabs mb-4" id="parametresTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('commande.liste.vente')); ?>">
                <button class="nav-link" id="commandes-tab">
                    <i class="fas fa-list-alt me-2"></i> Listes par commandes
                </button>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('vente.liste')); ?>">
                <button class="nav-link active">
                    <i class="fas fa-shopping-cart me-2"></i> Listes ventes
                </button>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('paiment.boissons' ,['id' => $commande_id ])); ?>">
                <button class="nav-link">
                    <i class="fas fa-history me-2"></i> Historique des paiements
                </button>
            </a>
        </li>
        <?php if($exist == true): ?>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('vente.rendu' ,['id' => $commande_id ])); ?>">
                <button class="nav-link">
                    <i class="fas fa-list me-2"></i>Article à rendre
                </button>
            </a>
        </li>
        <?php endif; ?>
        <?php if($commande->etat_client == 2): ?>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('rendre.boissons',['id' => $commande_id ])); ?>">
                <button class="nav-link">
                    <i class="fas fa-file-alt me-2"></i> Compte rendu
                </button>
            </a>
        </li>
        <?php endif; ?>
        <?php if($commande->etat_commande == 'non payé' && $commande->etat_client != 2): ?>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="#" data-toggle="modal" data-target="#payement">
                <button class="nav-link active bg-success text-white">
                    <i class="fas fa-credit-card me-2 text-white"></i> Payement
                </button>
            </a>
        </li>
        <?php endif; ?>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('vente.page')); ?>">
                <button class="nav-link active bg-dark text-white">
                    <i class="fas fa-cart-plus me-2 text-white"></i> Nouvel vente
                </button>
            </a>
        </li>
    </ul>
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-dark text-white py-3">
            <h5 class="mb-0 font-weight-bold text-white">
                <i class="fas fa-user me-2"></i>INFORMATIONS CLIENT
            </h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <p><strong>Nom :</strong> <?php echo e($commande->client->nom ?? 'N/A'); ?></p>
                    <p><strong>État commande :</strong>
                        <span class="ml-2 text-<?php echo e($commande->etat_commande == 'non payé' ? 'danger' : 'success'); ?>">
                            <?php echo e($commande->etat_commande); ?>

                        </span>
                    </p>
                </div>
                <div class="col-md-4">
                    <p><strong>Téléphone :</strong> <?php echo e($commande->client->telephone ?? 'N/A'); ?></p>
                    <p><strong>Email :</strong> <?php echo e($commande->client->email ?? 'N/A'); ?></p>
                </div>
                <div class="col-md-4">
                    <p><strong>Adresse :</strong> <?php echo e($commande->client->adresse ?? 'N/A'); ?></p>
                    <p><strong>Date commande :</strong> <?php echo e($commande->created_at); ?></p>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Card -->
    <div class="card shadow-sm">
        <!-- Card Header -->
        <div class="card-header d-flex justify-content-between align-items-center bg-dark text-white py-3">
            <h5 class="mb-0 font-weight-bold text-white">
                <i class="fas fa-receipt me-2"></i>VENTE - DETAILS C-<?php echo e($commande->id); ?>

            </h5>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('pdf.download',['id' => $commande_id])); ?>" class="btn btn-warning btn-sm text-white">
                    <i class="fas fa-print me-1 text-white"></i>Facture
                </a>
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary btn-sm">
                    <i class="fas fa-arrow-left me-1 text-white"></i>Retour
                </a>
            </div>
        </div>

        <!-- Card Body -->
        <div class="card-body p-4">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <!-- Ventes Table -->
            <div class="table-responsive mb-4">
                <table class="table table-bordered table-hover" id="dataTable">
                    <thead class="table-secondary">
                        <tr>
                            <th>ID</th>
                            <th>Article</th>
                            <th>CGT/BTL</th>
                            <th>BTL</th>
                            <th>CGT</th>
                            <th>Statut</th>
                            <th>Quantité</th>
                            <th>Prix</th>
                            <th>Total</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $prixGlobale = 0;$deconsigneglobale = 0 ; $totalconsigne = 0; $totalbtl = 0; $totalcgt = 0; $casse = 0 ; $casse_cgt = 0 ;$rendu_btl=0 ; $rendu_cgt = 0; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                        $highlightedId = session('highlighted_id');
                        $bouteilleNonRendu = $vente['etat'] == 'non rendu';
                        $cageotNonRendu = $vente['etat_cgt'] == 'non rendu';
                        ?>

                        <tr id="row-<?php echo e($vente['id']); ?>" class="<?php echo e($highlightedId == $vente['id'] ? 'bg-info' : ''); ?>">
                            <td class="fw-bold"><?php echo e($vente['id']); ?></td>
                            <td><?php echo e($vente['article']); ?></td>
                            <td>
                                <?php if(($vente['consignation'] ?? 0) + ($vente['prix_cgt'] ?? 0) > 0): ?>
                                <?php if($vente['etat_client'] == 1): ?>
                                <span class="fw-bold text-danger">à rendre</span>
                                <?php elseif($vente['etat_client_commande'] == 2 ): ?>
                                <span class="fw-bold text-danger">à disposition</span>
                                <?php else: ?>
                                <span class="badge bg-light text-dark">
                                    <?php echo e(number_format(($vente['consignation'] ?? 0) + ($vente['prix_cgt'] ?? 0), 0, ',', ' ')); ?> Ar
                                </span>
                                <?php endif; ?>
                                <?php else: ?>
                                <span>--</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($vente['etat'] == 'non rendu' ? 'bg-danger text-white' : 'bg-success text-white'); ?>">
                                    <?php echo e($vente['etat'] ?($vente['prix_consignation'] == 0 ? 0 : $vente['consignation'] / $vente['prix_consignation']) : '--'); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo e(in_array($vente['etat_cgt'], ['non rendu']) ? 'bg-danger text-white' : 'bg-success text-white'); ?>">
                                    <?php echo e($vente['etat_cgt'] ?($vente['consi_cgt'] == 0 ? 0 : $vente['prix_cgt'] / $vente['consi_cgt']):'--'); ?>

                                </span>
                            </td>
                            <td>
                                <span class="badge <?php echo e($vente['etat_payement'] == 0 ? 'bg-danger-light text-danger' : 'bg-success-light text-success'); ?>">
                                    <i class="fas <?php echo e($vente['etat_payement'] == 0 ? 'fa-times-circle text-danger' : 'fa-check-circle text-success'); ?> me-1"></i>
                                    <?php echo e($vente['etat_payement'] == 0 ? '' : ''); ?>

                                </span>
                            </td>
                            <td class="fw-bold"><?php echo e($vente['quantite']); ?> <?php echo e($vente['type_achat']); ?></td>
                            <td>
                                <?php echo e(number_format($vente['prix_unitaire'], 0, ',', ' ')); ?> Ar
                                <?php if (! ($vente['etat_client'] == 1 || $vente['etat'] == 'rendu' || $vente['etat'] == 'non consigné' || !isset($vente['etat']))): ?>
                                + <?php echo e(number_format($vente['prix_consignation'], 0, ',', ' ')); ?> Ar
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                $prix_total = ($vente['type_achat'] === 'cageot' || $vente['type_achat'] === 'pack')
                                ? ($vente['prix_unitaire'] * $vente['quantite'] * $vente['conditionnement']) + $vente['consignation'] + $vente['prix_cgt']
                                : ($vente['prix_unitaire'] * $vente['quantite']) + $vente['consignation'] + $vente['prix_cgt'];

                                if($commande->etat_client == 1) {
                                $prix_total -= $vente['consignation'] + $vente['prix_cgt'];
                                }
                                $prix_total_deconsigne = ($vente['type_achat'] === 'cageot' || $vente['type_achat'] === 'pack')
                                ? ($vente['prix_unitaire'] * $vente['quantite'] * $vente['conditionnement'])
                                : ($vente['prix_unitaire'] * $vente['quantite']);
                                $casse += $vente['casse'];
                                $casse_cgt += $vente['casse_cgt'];
                                $rendu_cgt += $vente['rendu_cgt'];
                                $rendu_btl += $vente['rendu_btl'];
                                $prix_total_consigne = $vente['consignation'] + $vente['prix_cgt'];
                                $totalbtl += $vente['prix_consignation'] == 0 ? 0 : $vente['consignation'] / $vente['prix_consignation'];
                                $totalcgt += $vente['consi_cgt'] == 0 ? 0 : $vente['prix_cgt'] / $vente['consi_cgt'];
                                $totalconsigne += $prix_total_consigne;
                                $deconsigneglobale += $prix_total_deconsigne;
                                $prixGlobale += $prix_total;
                                ?>

                                <?php echo e(number_format($prix_total, 0, ',', ' ')); ?> Ar
                            </td>
                            <td class="text-end">
                                <?php if($vente['etat_client_commande'] != 2): ?>
                                <a href="#" data-toggle="modal" data-target="#venteModal2<?php echo e($vente['id']); ?>" class="text-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>

                        <!-- Modal for each vente -->
                        <div class="modal fade" id="venteModal2<?php echo e($vente['id']); ?>" tabindex="-1" role="dialog" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered modal-lg">
                                <div class="modal-content border-0 shadow-lg rounded-3">
                                    <div class="modal-header bg-dark text-white border-bottom-0">
                                        <h5 class="modal-title">Déconsignation</h5>
                                        <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Close"></button>
                                    </div>

                                    <form action="<?php echo e(route('payer.consignation')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body px-4 py-3">

                                            <!-- Champs cachés -->
                                            <input type="hidden" name="vente_id" value="<?php echo e($vente['id']); ?>">
                                            <input type="hidden" name="commande_id" value="<?php echo e($vente['numero_commande']); ?>">
                                            <input type="hidden" name="consignation_id" value="<?php echo e($vente['consignation_id']); ?>">
                                            <input type="hidden" name="article_id" value="<?php echo e($vente['article_id']); ?>">
                                            <input type="hidden" name="total_btl" value="<?php echo e($vente['prix_consignation'] != 0 ? $vente['consignation'] / $vente['prix_consignation'] : 0); ?>">
                                            <input type="hidden" name="total_cgt" value="<?php echo e($vente['consi_cgt'] != 0 ? $vente['prix_cgt'] / $vente['consi_cgt'] : 0); ?>">

                                            <!-- Section bouteilles et cageots -->
                                            <div class="row">
                                                <div class="col-md-6 mb-4">
                                                    <label class="form-label fw-bold">Bouteilles</label>
                                                    <div class="form-check mb-2">

                                                        <input class="form-check-input" type="checkbox" name="check_bouteille" id="check_bouteille<?php echo e($vente['id']); ?>" <?php echo e($vente['prix_consignation'] != 0 ? ($vente['consignation'] / $vente['prix_consignation'] == 0 ? 'disabled' : '') : 'disabled'); ?>>
                                                        <label class="form-check-label" for="check_bouteille<?php echo e($vente['id']); ?>">
                                                            À rendre - <?php echo e($vente['prix_consignation'] != 0 ? ($vente['consignation'] / $vente['prix_consignation']) : 0); ?>

                                                        </label>
                                                    </div>
                                                    <input type="number" name="quantite_buteille" class="form-control" placeholder="Quantité" min="0" step="1"
                                                        <?php echo e($vente['prix_consignation'] != 0 ? ($vente['consignation'] / $vente['prix_consignation'] == 0 ? 'readonly' : '') : 'readonly'); ?>>
                                                </div>

                                                <div class="col-md-6 mb-4">
                                                    <label class="form-label fw-bold">Cageots</label>
                                                    <div class="form-check mb-2">
                                                        <input class="form-check-input" type="checkbox" name="check_cageot" id="check_cageot<?php echo e($vente['id']); ?>" <?php echo e($vente['consi_cgt'] != 0 ? ($vente['prix_cgt'] / $vente['consi_cgt'] == 0 ? 'disabled' : '') : 'disabled'); ?>>
                                                        <label class="form-check-label" for="check_cageot<?php echo e($vente['id']); ?>">
                                                            À rendre - <?php echo e($vente['consi_cgt'] != 0 ? ($vente['prix_cgt'] / $vente['consi_cgt']) : 0); ?>

                                                        </label>
                                                    </div>
                                                    <input type="number" name="quantite_cageot" class="form-control" placeholder="Quantité" min="0" step="1"
                                                        <?php echo e($vente['consi_cgt'] != 0 ? ($vente['prix_cgt'] / $vente['consi_cgt'] == 0 ? 'readonly' : '') : 'readonly'); ?>>
                                                </div>
                                            </div>

                                            <!-- Casse -->
                                            <div class="row">
                                                <div class="col-md-6 mb-4">
                                                    <label class="form-label fw-bold">Casse - Bouteilles</label>
                                                    <!-- <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" name="check_bouteille_casse" id="check_bouteille_casse<?php echo e($vente['id']); ?>">
                                <label class="form-check-label" for="check_bouteille_casse<?php echo e($vente['id']); ?>">
                                    Casse ou perte
                                </label>
                            </div> -->
                                                    <input type="number" name="casse" class="form-control" placeholder="Quantité cassée" min="0" step="1" <?php echo e($vente['prix_consignation'] != 0 ? ($vente['consignation'] / $vente['prix_consignation'] == 0 ? 'readonly' : '') : 'readonly'); ?>>
                                                </div>

                                                <div class="col-md-6 mb-4">
                                                    <label class="form-label fw-bold">Casse - Cageots</label>
                                                    <input type="number" name="cageot_casse" class="form-control" placeholder="Quantité cassée" min="0" step="1" <?php echo e($vente['consi_cgt'] != 0 ? ($vente['prix_cgt'] / $vente['consi_cgt'] == 0 ? 'readonly' : '') : 'readonly'); ?>>
                                                </div>
                                            </div>

                                            <!-- État rendu -->
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <div class="alert <?php echo e($vente['etat'] == 'avec BTL' ? 'alert-warning' : 'alert-success'); ?>">
                                                        <strong>Bouteille :</strong>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 mb-3">
                                                    <div class="alert <?php echo e(in_array($vente['etat_cgt'], ['avec CGT', 'non condi°']) ? 'alert-warning' : 'alert-success'); ?>">
                                                        <strong>Cageot</strong>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Footer -->
                                        <div class="modal-footer border-top-0 px-4 pb-4">
                                            <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Annuler</button>
                                            <?php
                                            $disabled = true;

                                            if ($vente['prix_consignation'] != 0 && $vente['consi_cgt'] != 0) {
                                            $ratio1 = $vente['consignation'] / $vente['prix_consignation'];
                                            $ratio2 = $vente['prix_cgt'] / $vente['consi_cgt'];

                                            if (!($ratio1 == 0 && $ratio2 == 0)) {
                                            $disabled = false;
                                            }
                                            }
                                            ?>

                                            <button type="submit" class="btn btn-primary" <?php echo e($disabled ? 'disabled' : ''); ?>>Valider</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="11" class="text-center text-muted py-4">
                                <i class="fas fa-exclamation-circle me-2"></i>Aucune donnée disponible
                            </td>
                        </tr>
                        <?php endif; ?>

                        <!-- Total Row -->
                        <tr class="table-active fw-bold">
                            <td colspan="" class="text-end"></td>
                            <td>Cageot rendu</td>
                            <td><?php echo e($rendu_cgt); ?></td>
                            <td colspan="2">Bouteille rendu</td>
                            <td><?php echo e($rendu_btl); ?></td>
                            <td></td>
                            <td colspan="">Total :</td>
                            <td colspan="2"><?php echo e(number_format($prixGlobale, 0, ',', ' ')); ?> Ar</td>

                        </tr>
                        <tr class="table-active fw-bold">
                            <td colspan="" class="text-end"></td>
                            <td>Bouteille cassé :</td>
                            <td><?php echo e($casse); ?></td>
                            <td colspan="2">Bouteille consigné :</td>
                            <td><?php echo e($totalbtl); ?></td>
                            <td></td>
                            <td>Total déconsigné:</td>
                            <td colspan="2"><?php echo e(number_format($deconsigneglobale, 0, ',', ' ')); ?> Ar</td>
                        </tr>
                        <tr class="table-active fw-bold">
                            <td colspan="" class="text-end"></td>
                            <td>Cageot endomagé / perdu :</td>
                            <td><?php echo e($casse_cgt); ?></td>
                            <td colspan="2">Cageot consigné :</td>
                            <td><?php echo e($totalcgt + optional($conditionnement->conditionnement)->nombre_cageot); ?></td>
                            <td></td>
                            <td>Total consignation:</td>
                            <td colspan="2"><?php echo e(number_format($totalconsigne + (optional($conditionnement->conditionnement)->nombre_cageot * $cgt), 0, ',', ' ')); ?> Ar</td>
                        </tr>
                        <?php
                        // Calcul sécurisé avec gestion des valeurs nulles
                        $nombreCageots = optional($conditionnement->conditionnement)->nombre_cageot ?? 0;
                        $valeurCageots = $nombreCageots * ($cgt ?? 0);
                        $totalConsigne = ($totalconsigne ?? 0) + $valeurCageots;
                        $montantTotal = ($deconsigneglobale - $reste < 0 ? 0 : $deconsigneglobale - $reste) + $totalConsigne;
                            ?>
                            <tr class="table-active fw-bold">
                            <td colspan="6" class="text-end"></td>
                            <td></td>
                            <td colspan="" class="text-danger">
                                <?php if($commande->etat_commande == 'non payé' && $totalConsigne > 0): ?>
                                Reste à payer
                                <?php elseif($commande->etat_commande == 'payé' && $totalConsigne > 0): ?>
                                <span class="text-success">Bouteille déconsignable</span>

                                <?php elseif($commande->etat_commande == 'non payé' && $totalConsigne == 0): ?>
                                <span class="text-danger">Reste à payer</span>
                                <?php else: ?>
                                <span class="text-success">reglé</span>
                                <?php endif; ?>
                            </td>
                            <!-- <td colspan="2"><?php echo e(number_format($deconsigneglobale - $reste, 0, ',', ' ')); ?> Ar</td> -->
                            <td colspan="2" class="text-end pe-4 fw-bold">


                                <!-- Affichage détaillé -->
                                <div class="d-flex flex-column">
                                    <span><?php echo e($deconsigneglobale - $reste < 0 ? 0 : $deconsigneglobale - $reste); ?> Ar (déconsigne)</span>
                                    <span class="text-success">+ <?php echo e(number_format($totalconsigne ?? 0, 0, ',', ' ')); ?> Ar (consigne bouteilles)</span>
                                    <?php if($nombreCageots > 0): ?>
                                    <span class="text-info">+ <?php echo e(number_format($valeurCageots, 0, ',', ' ')); ?> Ar (<?php echo e($nombreCageots); ?> cageots)</span>
                                    <?php endif; ?>
                                    <div class="border-top mt-1 pt-1">
                                        <span class="fw-bolder">= <?php echo e(number_format($montantTotal, 0, ',', ' ')); ?> Ar (total)</span>
                                    </div>
                                </div>
                            </td>
                            </tr>
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-3">
                    <?php echo e($ventes->links('pagination::bootstrap-4')); ?>

                </div>
            </div>

            <!-- Conditionnement Section -->
            <div class="mt-4">
                <!-- <h5 class="d-flex align-items-center text-uppercase fw-bold mb-3">
                    <img src="<?php echo e(asset('assets/images/enter.png')); ?>" alt="Conditionnement" width="24" class="me-2">
                    Conditionnement
                </h5> -->
                <hr class="mt-0">

                <div class="table-responsive mb-4">
                    <table class="table table-bordered">
                        <?php if($conditionnement != null): ?>
                        <thead class="table-secondary">
                            <tr>
                                <th>ID</th>
                                <th>Prix Cageot</th>
                                <th>Nombre Cageot</th>
                                <th>Total</th>
                                <th>État</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e(optional($conditionnement->conditionnement)->id ?? 'N/A'); ?></td>
                                <td><?php echo e(optional($conditionnement->conditionnement)->id ? $cgt .' Ar/CGT' : 'N/A'); ?></td>
                                <td><?php echo e(optional($conditionnement->conditionnement)->nombre_cageot ? optional($conditionnement->conditionnement)->nombre_cageot. ' CGT' : 'N/A'); ?></td>
                                <td><?php echo e(optional($conditionnement->conditionnement)->nombre_cageot ? number_format(optional($conditionnement->conditionnement)->nombre_cageot * $cgt, 0, ',', ' ') .' Ar' : 'N/A'); ?></td>
                                <td><?php echo e(optional($conditionnement->conditionnement)->etat ?? 'N/A'); ?></td>
                                <td><?php echo e(optional($conditionnement->conditionnement)->created_at ? optional($conditionnement->conditionnement)->created_at->format('d/m/Y H:i') : 'N/A'); ?></td>
                                <td>
                                    <?php if(optional($conditionnement->conditionnement)->id): ?>
                                    <a href="#" data-toggle="modal" data-target="#venteModal2" class="text-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                        <?php else: ?>
                        <tbody>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-3">
                                    <i class="fas fa-info-circle me-2"></i>Aucun conditionnement enregistré
                                </td>
                            </tr>
                        </tbody>
                        <?php endif; ?>
                        <tr class="table-active fw-bold">
                            <td colspan="6" class="text-end uppercase">Total globale :</td>
                            <td class=""><span class=""><?php if($commande->etat_client == 1): ?>
                                    <?php echo e(number_format($prixGlobale, 0, ',', ' ')); ?> Ar
                                    <?php else: ?>
                                    <?php echo e(number_format(optional($conditionnement->conditionnement)->id ? $prixGlobale + ($cgt * optional($conditionnement->conditionnement)->nombre_cageot) : $prixGlobale, 0, ',', ' ')); ?> Ar
                                    <?php endif; ?></span>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- Global Total -->

            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="venteModal2" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title">Déconsignaton cageot</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e((route('payer.condi'))); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="commande_id" value="<?php echo e($commande_id); ?>">
                    <p>Confirmer cette action?</p>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">rendre</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="payement" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title">regler payement</h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('regler.payement')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="commande_id" value="<?php echo e($commande_id); ?>">
                    <input type="hidden" name="montant_total"
                        value="<?php echo e($deconsigneglobale); ?>">
                    <input type="hidden" name="montant_tot"
                        value="<?php echo e($montantTotal); ?>">
                    <input type="hidden" name="totalconsigne"
                        value="<?php echo e($totalconsigne + (optional($conditionnement->conditionnement)->nombre_cageot * $cgt)); ?>">
                    <?php if($deconsigneglobale - $reste <= 0): ?>
                        <p class="text-danger">Le payement a déjà pour l'eau a déjà été fait.</p>
                        <?php else: ?>
                        <p>voulez-vous regler le payement de cette commande <?php echo e($commande_id); ?>? somme restant à payer <span class="text-danger"><?php echo e($deconsigneglobale - $reste); ?></span> Ar </p>
                        <input type="number" name="somme" class="form-control" placeholder="montant" max="<?php echo e($prixGlobale - $reste); ?>">
                        <?php endif; ?>
                        <div class="m-5 form-group">
                            <input type="checkbox" id="all" name="all" class="form-check-input">
                            <label for="all">Tout regler en Argent (Avec BTL + CGT) <br>
                                <span class="fw-bold text-success"><?php echo e($montantTotal); ?> Ar</span>
                            </label>
                        </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Payer</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll('input[type="checkbox"][name="check_bouteille_casse"]').forEach(function(checkbox) {
            checkbox.addEventListener('change', function() {
                const modalBody = this.closest('.modal-body');
                const venteId = this.id.replace('check_bouteille_casse', '');

                const inputCasse = modalBody.querySelector(`#bouteille_casse_input${venteId}`);
                const cageotContainer = modalBody.querySelector('#cageot_container');
                const bouteilleContainer = modalBody.querySelector('#bouteille_container');
                const titre = modalBody.querySelector('#titre');
                const cageotCasseContainer = modalBody.querySelector(`#cageot_casse_container${venteId}`);

                if (inputCasse && cageotContainer && bouteilleContainer && cageotCasseContainer) {
                    const isChecked = this.checked;
                    inputCasse.style.display = isChecked ? 'block' : 'none';
                    cageotContainer.style.display = isChecked ? 'none' : 'block';
                    bouteilleContainer.style.display = isChecked ? 'none' : 'block';
                    cageotCasseContainer.style.display = isChecked ? 'block' : 'none';
                    titre.style.display = isChecked ? 'block' : 'none';
                }
            });
        });
    });
    document.addEventListener('DOMContentLoaded', function() {
        // Gestion de la checkbox "Tout régler"
        const allCheckbox = document.getElementById('all');
        const sommeInput = document.querySelector('input[name="somme"]');

        if (allCheckbox && sommeInput) {
            allCheckbox.addEventListener('change', function() {
                if (this.checked) {
                    // Remplir automatiquement avec le montant max quand "Tout régler" est coché
                    sommeInput.value = '';
                    sommeInput.readOnly = true;
                } else {
                    sommeInput.value = '';
                    sommeInput.readOnly = false;
                }
            });

            // Validation du montant saisi
            sommeInput.addEventListener('input', function() {
                const max = parseFloat(this.max);
                const value = parseFloat(this.value) || 0;

                if (value > max) {
                    this.value = max;
                    alert(`Le montant ne peut pas dépasser ${max} Ar`);
                }
            });
        }

        // Gestion soumission du formulaire
        const paymentForm = document.querySelector('.modal-body').closest('form');
        if (paymentForm) {
            paymentForm.addEventListener('submit', function(e) {
                const reste = parseFloat("<?php echo e($deconsigneglobale - $reste); ?>");

                if (reste > 0) {
                    const montantSaisi = parseFloat(sommeInput.value) || 0;
                    if (montantSaisi <= 0) {
                        e.preventDefault();
                        alert('Veuillez saisir un montant valide');
                        return;
                    }
                }

                // Afficher un loader pendant le traitement
                const submitBtn = paymentForm.querySelector('[type="submit"]');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Traitement...';
            });
        }
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/vente/Detail.blade.php ENDPATH**/ ?>