<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Facture C-<?php echo e($commande->id); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        .header { margin-bottom: 20px; }
        .company-info { float: left; width: 50%; }
        .invoice-info { float: right; width: 40%; text-align: right; }
        .clear { clear: both; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .text-danger { color: #dc3545; }
        .text-success { color: #28a745; }
        .text-info { color: #17a2b8; }
        .fw-bold { font-weight: bold; }
        .fw-bolder { font-weight: bolder; }
        .table-active { background-color: rgba(0,0,0,.05); }
        .border-top { border-top: 1px solid #dee2e6; }
        .mt-1 { margin-top: 0.25rem; }
        .pt-1 { padding-top: 0.25rem; }
        .d-flex { display: flex; }
        .flex-column { flex-direction: column; }
        .pe-4 { padding-right: 1.5rem; }
    </style>
</head>
<body>
    <div class="header">
        <div class="company-info">
            <h2>Mourad - Bars</h2>
            <p>Tél: <?php echo e($company['phone']); ?></p>
        </div>
        <div class="invoice-info">
            <h2>Facture #F-<?php echo e($commande->id); ?></h2>
            <p>Date: <?php echo e($date); ?></p>
            <p>Commande: C-<?php echo e($commande->id); ?></p>
            <?php if($commande->client): ?>
                <p>Client: <?php echo e($commande->client->nom); ?></p>
            <?php endif; ?>
            <p>Statut: 
                <span class="<?php echo e($commande->etat_commande == 'payé' ? 'text-success' : 'text-danger'); ?>">
                    <?php echo e($commande->etat_commande == 'payé' ? 'Payée' : 'Non payé'); ?>

                </span>
            </p>
        </div>
        <div class="clear"></div>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Article</th>
                <th>BTL</th>
                <th>CGT</th>
                <th>Quantité</th>
                <th>Prix unitaire</th>
                <th>Consignation</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ventes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vente['id']); ?></td>
                <td><?php echo e($vente['article']); ?></td>
                <td class="<?php echo e($vente['etat'] == 'non rendu' ? 'text-danger' : 'text-success'); ?>">
                    <?php echo e($vente['etat'] ? ($vente['prix_consignation'] == 0 ? 0 : $vente['consignation'] / $vente['prix_consignation']) : '--'); ?>

                </td>
                <td class="<?php echo e(in_array($vente['etat_cgt'], ['non rendu']) ? 'text-danger' : 'text-success'); ?>">
                    <?php echo e($vente['etat_cgt'] ? ($vente['consi_cgt'] == 0 ? 0 : $vente['prix_cgt'] / $vente['consi_cgt']) : '--'); ?>

                </td>
                <td><?php echo e($vente['quantite']); ?> <?php echo e($vente['type_achat']); ?></td>
                <td class="text-right"><?php echo e(number_format($vente['prix_unitaire'], 0, ',', ' ')); ?> Ar</td>
                <td class="text-right">
                    <?php if(($vente['consignation'] + $vente['prix_cgt']) > 0): ?>
                        <?php if($vente['etat_client'] == 1): ?>
                            <span class="text-danger">à rendre</span>
                        <?php elseif($vente['etat_client_commande'] == 2): ?>
                            <span class="text-danger">à disposition</span>
                        <?php else: ?>
                            <?php echo e(number_format($vente['consignation'] + $vente['prix_cgt'], 0, ',', ' ')); ?> Ar
                        <?php endif; ?>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
                <td class="text-right">
                    <?php
                        $total = ($vente['type_achat'] === 'cageot' || $vente['type_achat'] === 'pack')
                            ? ($vente['prix_unitaire'] * $vente['quantite'] * $vente['conditionnement']) + $vente['consignation'] + $vente['prix_cgt']
                            : ($vente['prix_unitaire'] * $vente['quantite']) + $vente['consignation'] + $vente['prix_cgt'];

                        if($commande->etat_client == 1) {
                            $total -= $vente['consignation'] + $vente['prix_cgt'];
                        }
                    ?>
                    <?php echo e(number_format($total, 0, ',', ' ')); ?> Ar
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Résumé -->
    <table class="table-active">
        <tr>
            <td class="fw-bold">Bouteilles rendues:</td>
            <td><?php echo e($totals['rendu_btl']); ?></td>
            <td class="fw-bold">Cageots rendus:</td>
            <td><?php echo e($totals['rendu_cgt']); ?></td>
        </tr>
        <tr>
            <td class="fw-bold">Bouteilles cassées:</td>
            <td class="text-danger"><?php echo e($totals['casse']); ?></td>
            <td class="fw-bold">Cageots endommagés:</td>
            <td class="text-danger"><?php echo e($totals['casse_cgt']); ?></td>
        </tr>
        <tr>
            <td class="fw-bold">Bouteilles consignées:</td>
            <td><?php echo e($totals['btl']); ?></td>
            <td class="fw-bold">Cageots consignés:</td>
            <td><?php echo e($totals['cgt'] + $nombreCageots); ?></td>
        </tr>
    </table>

    <?php if($nombreCageots > 0): ?>
    <table>
        <tr>
            <th>Nombre de cageots</th>
            <th>Prix unitaire</th>
            <th>Total</th>
        </tr>
        <tr>
            <td><?php echo e($nombreCageots); ?> CGT</td>
            <td class="text-right"><?php echo e(number_format($cgt, 0, ',', ' ')); ?> Ar</td>
            <td class="text-right"><?php echo e(number_format($valeurCageots, 0, ',', ' ')); ?> Ar</td>
        </tr>
    </table>
    <?php endif; ?>

    <!-- Totaux finaux -->
    <div style="margin-top: 20px;">
        <table style="width: 50%; margin-left: auto;">
            <tr>
                <th>Total déconsigné:</th>
                <td class="text-right"><?php echo e(number_format($totals['deconsigne'], 0, ',', ' ')); ?> Ar</td>
            </tr>
            <tr>
                <th>Total consignation:</th>
                <td class="text-right"><?php echo e(number_format($totals['consigne'] + $valeurCageots, 0, ',', ' ')); ?> Ar</td>
            </tr>
            <tr>
                <th>Total global:</th>
                <td class="text-right"><?php echo e(number_format($totals['global'], 0, ',', ' ')); ?> Ar</td>
            </tr>
            
            <?php if($commande->etat_commande == 'non payé'): ?>
            <tr>
                <th>Reste à payer:</th>
                <td class="text-right text-danger"><?php echo e(number_format($commande->etat_client == 1 ? $montantTotal - ($totals['consigne'] + $valeurCageots) : $montantTotal, 0, ',', ' ')); ?> Ar</td>
            </tr>
            <?php endif; ?>
            
            <?php if($reste > 0): ?>
            <tr>
                <th>Déjà payé:</th>
                <td class="text-right"><?php echo e(number_format($reste, 0, ',', ' ')); ?> Ar</td>
            </tr>
            <?php endif; ?>
            
            <tr>
                <td colspan="2" class="text-end pe-4 fw-bold">
                    <div class="d-flex flex-column">
                        <span><?php echo e(max($totals['deconsigne'] - $reste, 0)); ?> Ar (déconsigne)</span>
                        <span class="text-success">+ <?php echo e(number_format($totals['consigne'], 0, ',', ' ')); ?> Ar (consigne)</span>
                        <?php if($nombreCageots > 0): ?>
                        <span class="text-info">+ <?php echo e(number_format($valeurCageots, 0, ',', ' ')); ?> Ar (cageots)</span>
                        <?php endif; ?>
                        <div class="border-top mt-1 pt-1">
                            <span class="fw-bolder">= <?php echo e(number_format($montantTotal, 0, ',', ' ')); ?> Ar (total)</span>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>

    <div style="margin-top: 50px; text-align: center; font-size: 10px;">
        <p>Merci pour votre confiance</p>
    </div>
</body>
</html><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/facture.blade.php ENDPATH**/ ?>