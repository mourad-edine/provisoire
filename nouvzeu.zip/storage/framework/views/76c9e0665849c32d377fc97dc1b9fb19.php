

<?php $__env->startSection('title', 'Paramètres système'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0 bg-light" style="font-size : 0.85rem;">
    <!-- En-tête -->
    <div class="bg-dark px-4 py-3 border-bottom border-dark">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0 text-white">
                <i class="fas fa-cog me-2 text-warning"></i>Paramètres système
            </h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0 bg-transparent small">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>" class="text-warning">Dashboard</a></li>
                    <li class="breadcrumb-item active text-muted ">Paramètres</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Message de succès -->
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show m-4" role="alert">
            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Contenu principal -->
    <div class="px-4 py-3">
        <!-- Onglets -->
        <ul class="nav nav-tabs border-dark mb-3" id="settingsTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active text-dark fw-bold" id="consignation-tab" data-bs-toggle="tab" data-bs-target="#consignation" role="tab">
                    <i class="fas fa-wine-bottle me-2"></i>Consignation
                </button>
            </li>
            <li class="nav-item">
                <button class="nav-link text-dark fw-bold" id="utilisateur-tab" data-bs-toggle="tab" data-bs-target="#utilisateur" role="tab">
                    <i class="fas fa-users me-2"></i>Utilisateurs
                </button>
            </li>
        </ul>

        <div class="tab-content bg-white border border-top-0 rounded-bottom shadow-sm p-4 border-dark">
            <!-- Tab: Consignation -->
            <div class="tab-pane fade show active" id="consignation" role="tabpanel">
                <div class="row">
                    <!-- Tarifs actuels -->
                    <div class="col-md-6 mb-4">
                        <h6 class="text-dark fw-bold mb-3"><i class="fas fa-list me-2 text-dark"></i>Tarifs actuels</h6>
                        <div class="list-group">
                            <?php
                                $tarifs = [
                                    'Bouteille 30-33 cl' => $type33->prix_consignation ?? 0,
                                    'Bouteille 50-65 cl' => $type65->prix_consignation ?? 0,
                                    'Bouteille 100 cl' => $type100->prix_consignation ?? 0,
                                    'Cageot' => $type33->prix_cgt ?? 0,
                                ];
                            ?>

                            <?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $prix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="list-group-item d-flex justify-content-between border-dark">
                                    <span class="text-dark"><?php echo e($label); ?></span>
                                    <span class="fw-bold text-dark"><?php echo e(number_format($prix, 0, ',', ' ')); ?> Ar</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Formulaire -->
                    <div class="col-md-6">
                        <h6 class="text-dark fw-bold mb-3"><i class="fas fa-edit me-2 text-dark"></i>Modifier les tarifs</h6>
                        <form action="<?php echo e(route('parametre.store')); ?>" method="POST" class="p-3 bg-white rounded border border-dark">
                            <?php echo csrf_field(); ?>
                            <?php $__currentLoopData = [
                                'Bouteille 30-33 cl' => 'consignation_bouteille_33',
                                'Bouteille 50-65 cl' => 'consignation_bouteille_65',
                                'Bouteille 100 cl' => 'consignation_bouteille_100',
                                'Cageot' => 'consignation_cageot'
                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mb-3">
                                    <label class="form-label text-dark"><?php echo e($label); ?></label>
                                    <div class="input-group">
                                        <input type="number" step="0.01" name="<?php echo e($name); ?>" class="form-control border-dark">
                                        <span class="input-group-text bg-white text-dark border-dark">Ar</span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <button type="submit" class="btn btn-dark w-100 mt-2">
                                <i class="fas fa-save me-2"></i>Enregistrer
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Tab: Utilisateurs -->
            <div class="tab-pane fade" id="utilisateur" role="tabpanel">
                <div class="row">
                    <!-- Ajouter utilisateur -->
                    <div class="col-md-5 mb-4">
                        <h6 class="text-dark fw-bold mb-3"><i class="fas fa-user-plus me-2 text-dark"></i>Ajouter un utilisateur</h6>
                        <form action="<?php echo e(route('add.user')); ?>" method="POST" class="p-3 bg-white border border-dark rounded">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label class="form-label text-dark">Nom complet</label>
                                <input type="text" name="name" class="form-control border-dark" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label text-dark">Email</label>
                                <input type="email" name="email" class="form-control border-dark" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label text-dark">Mot de passe</label>
                                <div class="input-group">
                                    <input type="password" name="password" class="form-control border-dark" required>
                                    <button type="button" class="btn btn-outline-dark toggle-password">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="form-check mb-3">
                                <input class="form-check-input border-dark" type="checkbox" name="is_admin" id="is_admin">
                                <label class="form-check-label text-dark" for="is_admin">Administrateur</label>
                            </div>
                            <button type="submit" class="btn btn-dark w-100">
                                <i class="fas fa-plus me-2"></i>Créer
                            </button>
                        </form>
                    </div>

                    <!-- Liste utilisateurs -->
                    <div class="col-md-7">
                        <h6 class="text-dark fw-bold mb-3"><i class="fas fa-users me-2 text-dark"></i>Liste des utilisateurs (<?php echo e(count($users)); ?>)</h6>
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover align-middle">
                                <thead class="table-dark text-white">
                                    <tr>
                                        <th>Nom</th>
                                        <th>Email</th>
                                        <th class="text-end">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="text-dark">
                                                <?php echo e($user->name); ?>

                                                <?php if($user->is_admin): ?>
                                                    <span class="badge bg-dark text-white ms-2">Admin</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-dark"><?php echo e($user->email); ?></td>
                                            <td class="text-end">
                                                <button class="btn  me-1">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button class="btn">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div> <!-- Fin Utilisateurs -->
        </div>
    </div> <!-- Fin Contenu principal -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.toggle-password').forEach(btn => {
            btn.addEventListener('click', function () {
                const input = this.closest('.input-group').querySelector('input');
                const icon = this.querySelector('i');
                const show = input.type === 'password';
                input.type = show ? 'text' : 'password';
                icon.classList.toggle('fa-eye');
                icon.classList.toggle('fa-eye-slash');
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mourad/Documents/provisoire/resources/views/pages/parametre/params.blade.php ENDPATH**/ ?>