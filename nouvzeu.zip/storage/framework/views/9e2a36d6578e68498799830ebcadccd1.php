<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->

    <ul class="nav nav-tabs border-bottom" id="parametresTabs" role="tablist">
        <li class="nav-item me-2" role="presentation">
            <a href="<?php echo e(route('stock.liste')); ?>" class="nav-link <?php echo e(request()->routeIs('stock.liste') ? 'active' : ''); ?>">
                <i class="fas fa-warehouse me-1"></i>Listes globales
            </a>
        </li>
        <li class="nav-item me-2" role="presentation">
            <a href="<?php echo e(route('stock.faible.liste')); ?>" class="nav-link <?php echo e(request()->routeIs('stock.faible.liste') ? 'active' : ''); ?>">
                <i class="fas fa-exclamation-triangle me-1"></i>Stocks faibles
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a href="<?php echo e(route('stock.categorie.liste')); ?>" class="nav-link <?php echo e(request()->routeIs('stock.categorie.liste') ? 'active' : ''); ?>">
                <i class="fas fa-th-large me-1"></i>Catégories
            </a>
        </li>
    </ul>
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header d-flex justify-content-between align-items-center bg-dark">
            <h5 class="text-white">Stock faible</h5>
            <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-primary btn-sm">
    <i class="fas fa-arrow-left mr-2"></i>Retour dashboard
</a>   
        </div>
        <div class="mt-3 ml-4 d-flex flex-wrap align-items-center gap-2 mb-2 mb-md-0">
            <form action="<?php echo e(route('stock.faible.liste')); ?>" method="GET" class="d-flex flex-wrap align-items-center gap-2">
                <?php echo csrf_field(); ?>
                <!-- Champ de recherche principal -->
                <div class="position-relative">
                    <input type="text" class="form-control form-control-sm" name="search" placeholder="Rechercher..." value="<?php echo e(old('search', request('search'))); ?>">
                </div>

                <!-- Filtres supplémentaires -->
                

                <!-- Tri des résultats -->
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-sort me-1"></i> Trier par
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="sortDropdown">
                        <li><button class="dropdown-item" type="submit"  value="nom_asc">Nom (A-Z)</button></li>
                        <li><button class="dropdown-item" type="submit"  value="nom_desc">Nom (Z-A)</button></li>
                        <li><button class="dropdown-item" type="submit"  value="prix_asc">Prix (Croissant)</button></li>
                        <li><button class="dropdown-item" type="submit"  value="prix_desc">Prix (Décroissant)</button></li>
                        <li><button class="dropdown-item" type="submit"  value="stock_asc">Stock (Croissant)</button></li>
                        <li><button class="dropdown-item" type="submit"  value="stock_desc">Stock (Décroissant)</button></li>
                    </ul>
                </div>
            </form>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>nom</th>
                            <th>categorie</th>
                            <th>P.Vente</th>
                            <th>P.Cageot</th>
                            <th>quantite</th>
                            <th>consignation</th>
                            <th>mise à jour</th>
                            <th>date</th>
                            <th>ajouter</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($article->id); ?></td>
                            <td><?php echo e($article->nom); ?></td>
                            <td><?php echo e($article->categorie_id); ?></td>
                            <td><?php echo e($article->prix_unitaire); ?> Ar</td>
                            <td><?php echo e($article->prix_conditionne ? $article->prix_conditionne :'pas de prix'); ?> Ar</td>
                            <td>
                                <?php
                                $quotient = intdiv($article->quantite, $article->conditionnement); // Division entière
                                $reste = $article->quantite % $article->conditionnement; // Reste de la division
                                $affichage = $quotient;
                                ?>
                                <span class="text-danger"> <?php echo e($affichage); ?> cageot<?php echo e($affichage > 1 ? 's' : ''); ?> <?php if($reste> 0): ?> et <?php echo e($reste); ?> unité<?php echo e($reste > 1 ? 's' : ''); ?><?php endif; ?>
                                </span>
                            </td>
                            <td><?php echo e($article->prix_consignation ? $article->prix_consignation .' Ar' :'pas de prix'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($article->created_at)->format('Y-m-d')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($article->updated_at)->format('Y-m-d')); ?></td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="<?php echo e(route('achat.page')); ?>"><i class="fas fa-edit text-secondary"></i></a>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="">
                                <div class="alert alert-warning mb-3">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    Pas de donnée trouvé --
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-start mt-3">
                    <?php echo e($articles->appends(['search' => request('search')])->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/stock/Faible.blade.php ENDPATH**/ ?>