<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facture</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: rgb(0 0 0 / 80%)
        }

        .header {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .contain {
            width: 100%;
            margin-top: 30px;
        }

        .contain div {
            display: inline-block;
            width: 32%;
            vertical-align: top;
        }

        .left,
        .center,
        .right {
            text-align: left;
        }

        .summary-section {
            margin-top: 30px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
        }

        .fin {
            margin-top: 20px;
        }

        .fin div {
            margin-top: 5px;
        }
    </style>
</head>

<body>

    <div class="header">Facture commande n° <?php echo e($commande->numero ?? '---'); ?></div>

    <div class="contain">
        <div class="left">
            <strong>Distributeur :</strong><br>
            Nom : Entreprise ABC<br>
            Adresse : -----------<br>
            Contact : -----------
        </div>

        <div class="right">
            <strong>Fournisseur :</strong><br>
            Nom : <?php echo e($commande->fournisseur->nom ?? '-'); ?><br>
            Adresse : <?php echo e($commande->fournisseur->adresse ?? '-'); ?><br>
            Contact : <?php echo e($commande->fournisseur->telephone ?? '-'); ?>

        </div>
    </div>

    <div class="contain">
        <div class="center">
            <strong>Date de commande :</strong><br>
            <?php echo e(\Carbon\Carbon::parse($commande->created_at)->format('d/m/Y')); ?>

        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>Article</th>
                <th>Prix / unité</th>
                <th>Quantité</th>
                <th>Prix Total</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $achats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $achat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($achat['article'] ?? '-'); ?></td>
                <td><?php echo e($achat['prix_unite']); ?> Ar</td>
                <td><?php echo e($achat['quantite']); ?> - <?php echo e($achat['type_achat']); ?></td>
                <td><?php echo e(number_format($achat['prix'], 2, ',', ' ')); ?> Ar</td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="summary-section">
        <div class="summary-row">
            <span><strong>Montant liquide :</strong></span>
            <span><?php echo e(number_format($total, 2, ',', ' ')); ?> Ar</span>
        </div>
    </div>

    <div class="fin">
        <div>
            <strong>Total TTC :</strong> <?php echo e(number_format($total, 2, ',', ' ')); ?> Ar
        </div>
        <div>
            <strong>Total quantité cageots :</strong>
            <?php echo e($achats->where('type_achat', 'cageot')->sum('quantite')); ?> cageots,
        </div>
        <div>
            <strong>Total quantité packs :</strong>
            <?php echo e($achats->where('type_achat', 'pack')->sum('quantite')); ?> packs,
        </div>
        <div>
            <strong>Total quantité bouteilles :</strong>
            <?php echo e($achats->where('type_achat', 'bouteilles')->sum('quantite')); ?> unités

        </div>
    </div>

</body>

</html>

<?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/pdf/facture.blade.php ENDPATH**/ ?>