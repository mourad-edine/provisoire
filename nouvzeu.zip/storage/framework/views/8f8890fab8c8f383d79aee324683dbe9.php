

<?php $__env->startSection('title', 'Tableau de Bord'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="font-size: 0.85rem;">
    <!-- Statistiques principales -->
    <div class="row g-3">
        <?php
        $cards = [
            [
                'title' => 'Nouvelle vente', 
                'value' => 'Commencer',
                'icon' => 'fa-cash-register',
                'color' => 'bg-vibrant-green',
                'text' => 'text-white',
                'link' => route('vente.page'),
                'action' => true
            ],
            [
                'title' => 'Approvisionnement', 
                'value' => 'Acheter',
                'icon' => 'fa-pallet',
                'color' => 'bg-vibrant-blue',
                'text' => 'text-white',
                'link' => route('achat.page'),
                'action' => true
            ]
        ];
        ?>

        <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-lg-4 col-md-6">
            <?php if(isset($card['link'])): ?>
            <a href="<?php echo e($card['link']); ?>" class="text-decoration-none card-hover-action">
            <?php endif; ?>
            
            <div class="card border-0 shadow-sm h-100 overflow-hidden">
                <div class="card-body p-3 <?php echo e($card['color']); ?> <?php echo e($card['text']); ?>">
                    <div class="d-flex align-items-center">
                        <div class="rounded-circle p-2 me-3 bg-white-30">
                            <i class="fas <?php echo e($card['icon']); ?>"></i>
                        </div>
                        <div class="flex-grow-1">
                            <h6 class="mb-1 small fw-medium"><?php echo e($card['title']); ?></h6>
                            <h5 class="mb-0 fw-bold">
                                <?php echo e($card['value']); ?>

                                <i class="fas fa-arrow-right ms-2 fa-xs"></i>
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php if(isset($card['link'])): ?>
            </a>
            <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Graphique des ventes -->
    <div class="row g-3 mt-3">
        <!-- Meilleures Ventes -->
        <div class="col-xl-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-bottom py-3">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-trophy me-2 text-warning"></i> Meilleures ventes</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4 py-3 text-uppercase small fw-bold" style="width: 70%">Produit</th>
                                    <th class="text-end pe-4 py-3 text-uppercase small fw-bold" style="width: 30%">Ventes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $meilleur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meilleu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-top border-bottom">
                                    <td class="ps-4 py-3">
                                        <div class="d-flex align-items-center">
                                            <span class="fw-medium text-dark"><?php echo e($meilleu->nom); ?></span>
                                        </div>
                                    </td>
                                    <td class="text-end pe-4 py-3 fw-bold text-primary">
                                        <?php echo e(number_format($meilleu->achats_count, 0, ',', ' ')); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="border-top border-bottom">
                                    <td colspan="2" class="text-center py-4 text-muted">
                                        <i class="fas fa-info-circle me-2"></i>Aucune donnée de vente disponible
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if(count($meilleur) > 0): ?>
                <div class="card-footer bg-white border-0 py-2 px-4">
                    <small class="text-muted">
                        <i class="fas fa-clock me-1"></i> Mis à jour à <?php echo e(now()->format('H:i')); ?>

                    </small>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Stocks Faibles -->
        <div class="col-xl-6">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-header bg-white border-bottom py-3">
                    <h6 class="mb-0 fw-bold"><i class="fas fa-exclamation-triangle me-2 text-danger"></i> Stocks faibles</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4 py-3 text-uppercase small fw-bold" style="width: 50%">Produit</th>
                                    <th class="text-end py-3 text-uppercase small fw-bold" style="width: 20%">Stock</th>
                                    <th class="text-end pe-4 py-3 text-uppercase small fw-bold" style="width: 30%">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $faible; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faib): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-top border-bottom">
                                    <td class="ps-4 py-3">
                                        <div class="d-flex align-items-center">
                                            <div class="avatar-sm rounded-circle me-3 d-flex align-items-center justify-content-center bg-light-<?php echo e($faib->quantite < 5 ? 'danger' : ($faib->quantite < 10 ? 'warning' : 'secondary')); ?>">
                                                <i class="fas fa-box-open text-<?php echo e($faib->quantite < 5 ? 'danger' : ($faib->quantite < 10 ? 'warning' : 'secondary')); ?>"></i>
                                            </div>
                                            <span class="fw-medium text-dark"><?php echo e($faib->nom); ?></span>
                                        </div>
                                    </td>
                                    <td class="text-end py-3 fw-bold <?php echo e($faib->quantite < 5 ? 'text-danger' : ($faib->quantite < 10 ? 'text-warning' : 'text-secondary')); ?>">
                                        <?php echo e(number_format($faib->quantite, 0, ',', ' ')); ?>

                                    </td>
                                    <td class="text-end pe-4 py-3">
                                        <?php if($faib->quantite < 5): ?>
                                        <span class="badge bg-danger text-white bg-opacity-15 text-danger px-3 py-1">URGENT</span>
                                        <?php elseif($faib->quantite < 10): ?>
                                        <span class="badge bg-warning text-white bg-opacity-15 text-warning px-3 py-1">ALERTE</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary text-white bg-opacity-15 text-secondary px-3 py-1">NORMAL</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="border-top border-bottom">
                                    <td colspan="3" class="text-center py-4 text-muted">
                                        <i class="fas fa-check-circle me-2 text-success"></i>Tous les stocks sont suffisants
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if(count($faible) > 0): ?>
                <div class="card-footer bg-white border-0 py-2 px-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">
                            <i class="fas fa-clock me-1"></i> Dernière mise à jour
                        </small>
                        <a href="<?php echo e(route('achat.page')); ?>" class="btn btn-sm btn-danger px-3">
                            <i class="fas fa-plus me-1"></i>Approvisionner
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<style>
   :root {
    --vibrant-green: #6bbf59; /* Vert adouci */
    --vibrant-blue: #5a9bd4;  /* Bleu adouci */
}

.bg-vibrant-green {
    background-color: var(--vibrant-green);
}

.bg-vibrant-blue {
    background-color: var(--vibrant-blue);
}

.btn-vibrant-blue {
    background-color: var(--vibrant-blue);
    border-color: var(--vibrant-blue);
    color: white;
}

.btn-vibrant-blue:hover {
    background-color: #4a8ac2;
    border-color: #4a8ac2;
}

    
    .bg-white-30 {
        background-color: rgba(255, 255, 255, 0.3);
    }
    
    .card-hover-action .card {
        transition: all 0.3s ease;
    }
    
    .card-hover-action:hover .card {
        transform: translateY(-1px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1) !important;
    }
    
    .card {
        border-radius: 0.5rem;
    }
    
    .avatar-sm {
        width: 32px;
        height: 32px;
        display: flex;
    }
    
    .table-hover tbody tr {
        transition: background-color 0.2s ease;
    }

     /* Styles pour les tableaux */
     .table {
        border-collapse: separate;
        border-spacing: 0;
    }
    
    .table thead th {
        border-bottom: 2px solid #e9ecef;
        border-top: none;
        vertical-align: middle;
    }
    
    .table tbody tr {
        transition: all 0.2s ease;
    }
    
    .table tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }
    
    .table tbody tr.border-top {
        border-top: 1px solid #e9ecef;
    }
    
    .table tbody tr.border-bottom {
        border-bottom: 1px solid #e9ecef;
    }
    
    .badge {
        font-size: 0.75rem;
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    
    .avatar-sm {
        width: 36px;
        height: 36px;
    }
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/Accueil.blade.php ENDPATH**/ ?>