

<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Navigation par onglets -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <ul class="nav nav-tabs" id="clientTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <a class="nav-link" href="<?php echo e(route('client.profil', ['id' => $client_id])); ?>">
                    <i class="fas fa-id-card me-2"></i>Profil client et Emballage
                </a>
            </li>
            
            <li class="nav-item" role="presentation">
                <a class="nav-link" href="<?php echo e(route('client.historique', ['id' => $client_id])); ?>">
                    <i class="fas fa-history me-2"></i> Historique
                </a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link active" href="<?php echo e(route('client.commande', ['id' => $client_id])); ?>">
                    <i class="fas fa-wine-bottle me-2"></i>Commandes
                </a>
            </li>
        </ul>
        
        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-dark btn-sm">
            <i class="fas fa-arrow-left me-1"></i> Retour
        </a>
    </div>

    <!-- Formulaire de recherche -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <input type="hidden" name="client_id" value="<?php echo e($client_id); ?>">

                <div class="col-md-2">
                    <label for="search" class="form-label">Nom | N° commande</label>
                    <input type="text" id="search" name="search" value="<?php echo e(request('search')); ?>" class="form-control form-control-sm" placeholder="Rechercher...">
                </div>
                <div class="col-md-2">
                    <label for="date_debut" class="form-label">Date début</label>
                    <input type="date" id="date_debut" name="date_debut" value="<?php echo e(request('date_debut')); ?>" class="form-control form-control-sm">
                </div>
                <div class="col-md-2">
                    <label for="date_fin" class="form-label">Date fin</label>
                    <input type="date" id="date_fin" name="date_fin" value="<?php echo e(request('date_fin')); ?>" class="form-control form-control-sm">
                </div>
                <div class="col-md-2">
                    <label for="tri" class="form-label">Trier par date</label>
                    <select name="tri" id="tri" class="form-select form-select-sm">
                        <option value="desc" <?php echo e(request('tri') == 'desc' ? 'selected' : ''); ?>>Décroissant</option>
                        <option value="asc" <?php echo e(request('tri') == 'asc' ? 'selected' : ''); ?>>Croissant</option>
                    </select>
                </div>
                <div class="col-md-2 align-self-end">
                    <button type="submit" class="btn btn-dark btn-sm">
                        <i class="fas fa-search me-1"></i> Rechercher
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Tableau des commandes -->
    <div class="card shadow">
    <div class="card-body">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>id client</th>
                            <th>date commande</th>
                            <th>nombre d'achat</th>
                            <th>sous-total</th>
                            <th>consignation</th>
                            <th>total</th>
                            <th>état</th>
                            <th>Options</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>C-<?php echo e($commande->id); ?></td>
                            <td><?php echo e($commande->client ? $commande->client->nom : 'client passager'); ?></td>
                            <td><?php echo e($commande->created_at); ?></td>
                            <td><?php echo e($commande->ventes_count); ?> </td>
                            <td><?php echo e($commande->ventes_total); ?>Ar</td>
                            <td>
                                <?php if($commande->etat_client == 1): ?>
                                <span class="fw-boldtext-danger"> à rendre</span>
                                <?php elseif($commande->etat_client == 2): ?>
                                <span class="fw-bold text-danger">à disposition</span>
                                <?php else: ?>
                                <?php echo e(number_format(
                                        $commande->ventes_consignation_sum_prix 
                                        + $commande->ventes_consignation_sum_prix_cgt 
                                        + optional($commande->conditionnement)->nombre_cageot * $cgt, 
                                        0, ',', ' '
                                )); ?> Ar
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($commande->etat_client == 1): ?>
                                <?php echo e(number_format($commande->ventes_total, 0, ',', ' ')); ?> Ar
                                <?php else: ?>
                                <?php echo e(number_format($commande->ventes_total + $commande->ventes_consignation_sum_prix + $commande->ventes_consignation_sum_prix_cgt + (optional($commande->conditionnement)->nombre_cageot * $cgt), 0, ',', ' ')); ?> Ar
                                <?php endif; ?>
                            </td>
                            <td><?php if($commande->etat_commande == 'payé'): ?>
                                <span class="text-success">
                                    <?php echo e($commande->etat_commande); ?>

                                </span>
                                <?php else: ?>
                                <span class="text-danger">non payé</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="<?php echo e(route('commande.liste.vente.detail', ['id' => $commande->id])); ?>" class=""><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('pdf.download' , ['id'=>$commande->id])); ?>" class="ml-3"><i class="fas fa-print text-warning"></i></a>
                                


                                <form action="#" method="POST" style="display:inline;">

                                </form>
                            </td>
                        </tr>
                        <div class="modal fade" id="venteModal2<?php echo e($commande->id); ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header bg-light">
                                        <h5 class="modal-title">regler payement</h5>
                                        <button type="button" class="close" data-dismiss="modal">
                                            <span>&times;</span>
                                        </button>
                                    </div>
                                    <form action="<?php echo e(route('regler.payement')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">
                                            <input type="hidden" name="commande_id" value="<?php echo e($commande->id); ?>">
                                            <p>voulez-vous regler le payement de cette commande <?php echo e($commande->id); ?>?</p>
                                        </div>
                                        <div class="modal-footer bg-light">
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>
                                            <button type="submit" class="btn btn-primary">Payer</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class=""><div class="alert alert-warning mb-3">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Pas de donnée trouvé -- 
                    </div></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-start mt-3">
                    <?php echo e($commandes->appends(['search' => request('search')])->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .nav-tabs .nav-link {
        border: none;
        color: #495057;
        padding: 0.75rem 1.25rem;
    }
    .nav-tabs .nav-link.active {
        color: #0d6efd;
        border-bottom: 3px solid #0d6efd;
        background-color: transparent;
    }
    .table th {
        white-space: nowrap;
    }
    .badge {
        font-weight: 500;
        padding: 0.35em 0.65em;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mourad/Documents/provisoire/resources/views/pages/clients/Commande.blade.php ENDPATH**/ ?>