

<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="">

    <!-- Page Heading -->

    <!-- DataTales Example -->
    <ul class="nav nav-tabs mb-4" id="parametresTabs" role="tablist">
    <li class="nav-item" role="presentation">
            <a style="text-decoration: none;" href="<?php echo e(route('achat.commande')); ?>">
                <button class="nav-link  active" id="utilisateur-tab" data-bs-toggle="tab" data-bs-target="#utilisateur" type="button" role="tab" aria-controls="utilisateur" aria-selected="false">
                    <i class="fas fa-user me-2"></i>Listes par commandes
                </button>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a style="text-decoration: none;" href="<?php echo e(route('achat.liste')); ?>">
                <button class="nav-link" id="consignation-tab" data-bs-toggle="tab" data-bs-target="#consignation" type="button" role="tab" aria-controls="consignation" aria-selected="true">
                    <i class="fas fa-wine-bottle me-2"></i>Listes achats
                </button>
            </a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link text-decoration-none p-0" href="<?php echo e(route('achat.page')); ?>">
                <button class="nav-link active bg-dark text-white">
                    <i class="fas fa-cart-plus me-2 text-white"></i> Nouvel achat
                </button>
            </a>
        </li>
       
    </ul>
    <div class="card shadow mb-4">
    <div class="p-3 mb-3 bg-light rounded shadow-sm">
            <form method="GET" action="<?php echo e(route('achat.commande')); ?>" class="row g-3 align-items-end">
                <div class="col-md-2">
                    <label for="search" class="form-label">Nom|numero commande</label>
                    <input type="text" id="search" name="search" value="<?php echo e(request('search')); ?>" class="form-control">
                </div>
                <div class="col-md-2">
                    <label for="date_debut" class="form-label">Date début</label>
                    <input type="date" id="date_debut" name="date_debut" value="<?php echo e(request('date_debut')); ?>" class="form-control">
                </div>
                <div class="col-md-2">
                    <label for="date_fin" class="form-label">Date fin</label>
                    <input type="date" id="date_fin" name="date_fin" value="<?php echo e(request('date_fin')); ?>" class="form-control">
                </div>
                <div class="col-md-3">
                    <label for="tri" class="form-label">Trier par date</label>
                    <select name="tri" id="tri" class="form-control">
                        <option value="desc" <?php echo e(request('tri') == 'desc' ? 'selected' : ''); ?>>Décroissant</option>
                        <option value="asc" <?php echo e(request('tri') == 'asc' ? 'selected' : ''); ?>>Croissant</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-dark w-100"><i class="fa fa-search"></i>Rechercher</button>
                </div>
            </form>
        </div>
        <div class="card-body">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>numero_commande</th>
                            <th>id fournisseur</th>
                            <th>date commande</th>
                            <th>nombre d'achat</th>
                            <th>total</th>
                            <th>Options</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>C-<?php echo e($commande->id); ?></td>
                            <td><?php echo e($commande->numero ? $commande->numero : 'pas de numero'); ?></td>
                            <td><?php echo e($commande->fournisseur ? $commande->fournisseur->nom : 'Nom fournisseur'); ?></td>
                            <td><?php echo e($commande->created_at); ?></td>
                            <td><?php echo e($commande->achats_count); ?> </td>
                            <td><?php echo e($commande->achats_sum_prix); ?> Ar</td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="<?php echo e(route('achat.commande.detail', ['id' => $commande->id])); ?>" class="mr-3"><i class="fas fa-eye"></i></a>
                                <a href="<?php echo e(route('pdf.achat' , ['id' => $commande->id])); ?>"><i class="fas fa-print text-warning"></i></a>
                                <form action="#" method="POST" style="display:inline;">

                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                        <div class="alert alert-warning mb-3">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Pas de donnée trouvé -- 
                    </div>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="d-flex justify-content-start mt-3">
                    <?php echo e($commandes->appends(['search' => request('search')])->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>

</div>

<!-- Modal Nouvel Achat -->
<!-- Modal Nouvel Achat -->
<div class="modal fade" id="achatModal" tabindex="-1" role="dialog" aria-labelledby="achatModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="achatModalLabel">Nouvel Achat</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="achatForm" method="POST" action="<?php echo e(route('achat.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <!-- Colonne 1 -->

                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="article">Article</label>
                                <select class="form-control select2" id="article">
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($article->id); ?>" data-prix="<?php echo e($article->prix_achat); ?>" data-condi="<?php echo e($article->conditionnement); ?>" data-prixcgt="<?php echo e($article->prix_cgt); ?>" data-consignation="<?php echo e($article->prix_consignation); ?>"><?php echo e($article->nom); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        

                        <!-- Colonne 2 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="fournisseur">Fournisseur</label>
                                <select class="form-control select2" id="fournisseur" name="fournisseur_id" required>
                                    <option value="">--choisir fournisseur--</option>
                                    <?php $__currentLoopData = $fournisseurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fournisseur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($fournisseur->id); ?>"><?php echo e($fournisseur->nom); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Colonne 1 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="quantite">Quantité en cageot</label>
                                <input type="number" class="form-control" id="quantite">
                            </div>
                        </div>

                        <!-- Colonne 2 -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="dateachat">Date</label>
                                <input type="date" class="form-control" id="dateachat" value="today">
                            </div>

                        </div>
                    </div>

                    <div class="row">
                        <!-- Colonne 1 -->
                        <div class="col-md-6">

                            <div class="form-group">
                                <label for="price">Total</label>
                                <input type="number" class="form-control" id="price" min="1">
                            </div>
                        </div>
                    </div>


                    <button type="button" class="btn btn-success" id="ajouterArticle">Ajouter</button>

                    <!-- Conteneur caché pour stocker les valeurs envoyées en POST -->
                    <div id="hiddenInputs"></div>

                    <table class="table mt-3">
                        <thead>
                            <tr>
                                <th>Article</th>
                                <th>Prix par cageot</th>
                                <th>Quantité</th>

                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody id="articlesTable"></tbody>
                    </table>

                    <div class="modal-footer">
                        <p id="total"></p><button type="submit" class="btn btn-primary">Valider</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Avant la fermeture du body -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/achat/commande.blade.php ENDPATH**/ ?>