

<?php $__env->startSection('title', 'Accueil'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Tables</h1>
    <p class="mb-4">Ajouter votre article
        .</p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Listes articles faibles</h6>
            <button class="btn btn-primary btn-sm">retour</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                        <th>id</th>
                            <th>nom</th>
                            <th>categorie</th>
                            <th>P.U</th>
                            <th>P.C</th>
                            <th>quantite</th>
                            <th>image</th>
                            <th>consignation</th>
                            <th>mise à jour</th>
                            <th>date creation</th>
                            <th>options</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>id</th>
                            <th>nom</th>
                            <th>categorie</th>
                            <th>P.U</th>
                            <th>P.C</th>
                            <th>quantite</th>
                            <th>image</th>
                            <th>consignation</th>
                            <th>mise à jour</th>
                            <th>date creation</th>
                            <th>options</th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($article->id); ?></td>
                            <td><?php echo e($article->nom); ?></td>
                            <td><?php echo e($article->categorie_id); ?></td>
                            <td><?php echo e($article->prix_unitaire); ?> Ar</td>
                            <td><?php echo e($article->prix_conditionne  ? $article->prix_conditionne :'pas de prix'); ?></td>
                            <td><?php echo e($article->quantite); ?></td>
                            <td><img src="<?php echo e(asset('assets/images/bouteille.jpg')); ?>" alt="" width="40" height="40"></td>
                            <td><?php echo e($article->prix_consignation ? $article->prix_consignation :'pas de prix'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($article->created_at)->format('Y-m-d')); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($article->updated_at)->format('Y-m-d')); ?></td>
                            <td>
                                <!-- Icônes d'options -->
                                <a href="#"><i class="fas fa-eye"></i></a>
                                <a href="#"><i class="fas fa-edit"></i></a>
                                <form action="#" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" style="background:none; border:none; color:red;"><i class="fas fa-trash-alt"></i></button>
                                </form>
                            </td>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td class="text-warning">pas encore de donné inséré pour le moment</td>
                            <td></td>
                            <td></td>
                        </tr>
                        <?php endif; ?>


                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.AdminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\provisoire\resources\views/pages/stock/Faible.blade.php ENDPATH**/ ?>